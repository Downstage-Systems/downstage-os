#!/usr/bin/env python3
"""ATEM SOURCES: one Stream Deck + XL page that replaces the 16 M/E x mode kit pages.

    python3 tools/atem-sources-page.py --host 192.168.2.223:8000 --page 27 [out.companionconfig]

Two page-wide selectors live in Companion custom variables:
  sb_me    which M/E every source key acts on (1..number of M/Es on the switcher)
  sb_mode  what a press does (PVW / CUT / AUTO / HOT + the custom modes in shows/modes.json)
Source keys keep only their input in a local variable. A press runs the selected mode's
recipe (internal logic_if on sb_mode) with mixeffect = $(custom:sb_me): the bmd-atem 4.x module
evaluates expressions in its options (proven by the kit's $(local:me) keys). Tally follows the
selected M/E; the key's border colour and tag follow the selected mode.

Switcher size (inputs, M/Es, media players, SuperSource) and source names are read from the
running Companion (read-only). The page's menu-icon key jumps to --page (Rob copies it onto the Menu).
"""
import base64, copy, gzip, importlib.util, json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location("atem_me_pages", os.path.join(HERE, "atem-me-pages.py"))
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
wrap, nid, rgb = gen.wrap, gen.nid, gen.rgb

DONOR = os.path.join(HERE, "show-builder", "donor-atem-page8.companionconfig")
EXAMPLE = json.loads(gzip.decompress(open(DONOR, "rb").read()))
KIT = gen.Kit(EXAMPLE)
ATEM_LABEL = next(iter(EXAMPLE["instances"].values()))["label"]
MENU_ICON = os.path.join(PROJECT, "button-pack", "atem-sources.png")

ME = "($(custom:sb_me) ?? 1)"
MODE = '($(custom:sb_mode) ?? "PVW")'
VIOLET = 0x8E6FE6


def hexint(h):
    return int(h.lstrip("#"), 16)


# ---------------------------------------------------------------- internal helpers

def set_lit(var, value):
    return {"type": "action", "id": nid(), "connectionId": "internal", "definitionId": "custom_variable_set_value",
            "options": {"name": wrap(var), "create": wrap(True), "value": wrap(str(value))}, "children": {}}


def cond_eq(var, value):
    return {"type": "feedback", "id": nid(), "definitionId": "variable_value", "connectionId": "internal",
            "options": {"variable": wrap(f"custom:{var}"), "op": wrap("eq"), "value": wrap(str(value))},
            "isInverted": wrap(False)}


def logic_if(cond, then, otherwise):
    return {"type": "action", "id": nid(), "definitionId": "logic_if", "connectionId": "internal", "options": {},
            "children": {"condition": [cond], "actions": list(then), "else_actions": list(otherwise)}}


def chain(var, cases, default):
    node = list(default)
    for value, acts in reversed(cases):
        node = [logic_if(cond_eq(var, value), acts, node)]
    return node


def fill(var, value, color, text=0):
    f = cond_eq(var, value)
    f["styleOverrides"] = [{"overrideId": nid(), "elementId": "box0", "elementProperty": "color", "override": wrap(color)},
                           {"overrideId": nid(), "elementId": "text0", "elementProperty": "color", "override": wrap(text)}]
    return f


def follow(obj):
    """Point an ATEM action/feedback's M/E at the page selector, its input at the key's local."""
    o = obj.get("options", {})
    if "mixeffect" in o:
        o["mixeffect"] = wrap(ME, True)
    if "input" in o:
        o["input"] = wrap("$(local:input)", True)
    return obj


# ---------------------------------------------------------------- keys

def mode_actions(mode):
    """The mode recipe's actions, aimed at the selected M/E (built by the kit's own mode_button)."""
    probe = KIT.mode_button(mode, 1, 1)
    return [follow(a) for a in probe["steps"]["0"]["action_sets"]["down"]]


def source_key(inp, modes):
    ctl = KIT.mode_button(modes["PVW"], 1, inp)                       # layer stack + preview/program feedbacks
    ctl["localVariables"] = [l for l in ctl["localVariables"] if l["variableName"] == "input"]
    cases = [(k, mode_actions(m)) for k, m in modes.items() if k != "PVW"]
    ctl["steps"]["0"]["action_sets"]["down"] = chain("sb_mode", cases, mode_actions(modes["PVW"]))
    ctl["feedbacks"] = [follow(f) for f in KIT.fresh(KIT.pvw)["feedbacks"]]   # green in preview, red on program
    # border colour and tag follow the selected mode
    color_expr = "".join(f'{MODE} == "{k}" ? {hexint(m["color"])} : ' for k, m in modes.items()) + str(hexint(modes["PVW"]["color"]))
    tag_expr = "".join(f'{MODE} == "{k}" ? "{m["tag"]}" : ' for k, m in modes.items()) + '"PVW"'
    layers = ctl["style"]["layers"]
    for l in layers:
        if l["id"] == "box0":
            l["borderColor"] = wrap(color_expr, True)
        elif l["id"] == "image0":
            l["enabled"] = wrap(False)
    tag = next(l for l in layers if l["type"] == "text" and str(l["text"]["value"]).startswith('concat("M"'))
    tag["text"] = wrap(f'concat("M", {ME}, " ", {tag_expr})', True)
    tag["color"] = wrap(color_expr, True)
    tag["x"] = wrap(0)
    return ctl


def me_key(n):
    ctl = KIT.title_button(f"M/E {n}", n)
    ctl["localVariables"] = []
    ctl["style"]["layers"] = [l for l in ctl["style"]["layers"] if not (l["type"] == "text" and l["id"] != "text0")]
    ctl["style"]["layers"].append(KIT.text_layer("SELECT", False, -34, 12, VIOLET))
    for l in ctl["style"]["layers"]:
        if l["id"] == "box0":
            l["borderColor"] = wrap(VIOLET)
    ctl["steps"]["0"]["action_sets"]["down"] = [set_lit("sb_me", n)]
    ctl["feedbacks"] = [fill("sb_me", n, VIOLET, 0xFFFFFF)]
    return ctl


def mode_key(key, mode):
    color = hexint(mode["color"])
    ctl = KIT.title_button(mode["tag"], 1)
    ctl["localVariables"] = []
    ctl["style"]["layers"] = [l for l in ctl["style"]["layers"] if not (l["type"] == "text" and l["id"] != "text0")]
    ctl["style"]["layers"].append(KIT.text_layer("MODE", False, -34, 12, color))
    for l in ctl["style"]["layers"]:
        if l["id"] == "box0":
            l["borderColor"] = wrap(color)
        elif l["id"] == "image0":
            l.update({"enabled": wrap(True), "base64Image": wrap(KIT.mode_glyph(mode, mode["color"])),
                      "x": wrap(7), "y": wrap(7), "width": wrap(22), "height": wrap(22),
                      "halign": wrap("left"), "valign": wrap("top"), "fillMode": wrap("fit")})
    ctl["steps"]["0"]["action_sets"]["down"] = [set_lit("sb_mode", key)]
    ctl["feedbacks"] = [fill("sb_mode", key, color, 0)]
    return ctl


def take_key(which):
    ctl = KIT.transition_button(which, 1)
    ctl["localVariables"] = []
    for a in ctl["steps"]["0"]["action_sets"]["down"]:
        follow(a)
    for f in ctl["feedbacks"]:
        follow(f)
    ctl["style"]["layers"].append(KIT.text_layer(f'concat("M/E ", {ME})', True, -34, 12, 0x9AA4AD))
    return ctl


def menu_icon_key(page_no):
    uri = "data:image/png;base64," + base64.b64encode(open(MENU_ICON, "rb").read()).decode()
    return KIT.nav_button(page_no, uri)


# ---------------------------------------------------------------- switcher discovery (read-only)

def read_var(host, name):
    try:
        v = urllib.request.urlopen(f"http://{host}/api/variable/{ATEM_LABEL}/{name}/value", timeout=3).read().decode().strip()
    except Exception:
        return None
    return None if (not v or v == "Not found") else v


def discover(host):
    inputs = []
    for i in range(1, 41):
        if read_var(host, f"short_{i}") is None:
            break
        inputs.append(i)
    mes = [m for m in (1, 2, 3, 4) if read_var(host, f"pgm{m}_input") is not None] or [1]
    extras = [i for i in (3010, 3020, 3030, 3040, 6000, 6001) if read_var(host, f"short_{i}") is not None]
    return inputs, mes, extras + [0, 2001]


def load_modes():
    modes = {k: dict(v) for k, v in gen.BUILTIN_MODES.items()}
    try:
        saved = json.load(open(os.path.join(PROJECT, "shows", "modes.json"))).get("modes", {})
    except Exception:
        saved = {}
    for k, v in saved.items():
        modes[k] = dict(modes.get(k, {}), **v)
    return modes


def build(host, page_no):
    inputs, mes, extras = discover(host)
    modes = load_modes()
    builtin = [k for k in gen.BUILTIN_MODES]
    custom = [k for k in modes if k not in gen.BUILTIN_MODES]
    c = {str(r): {} for r in range(4)}
    row0 = [KIT.nav_button(1)] + [me_key(m) for m in mes] + [mode_key(k, modes[k]) for k in builtin]
    row0 += [take_key("CUT"), take_key("AUTO")]
    if len(row0) > 9:
        raise SystemExit(f"top row needs {len(row0)} keys; more than 9 (4 M/Es) needs a second selector row")
    for col, ctl in enumerate(row0):
        c["0"][str(col)] = ctl
    slots = [(r, col) for r in (1, 2, 3) for col in range(9)]
    tail = [mode_key(k, modes[k]) for k in custom] + [menu_icon_key(page_no)]
    room = len(slots) - len(tail)
    sources = (inputs + extras)[:room]
    for (r, col), inp in zip(slots, sources):
        c[str(r)][str(col)] = source_key(inp, modes)
    for (r, col), ctl in zip(slots[-len(tail):], tail):
        c[str(r)][str(col)] = ctl
    page = {"version": EXAMPLE["version"], "type": "page", "companionBuild": EXAMPLE["companionBuild"],
            "page": {"id": nid(), "name": "ATEM SOURCES", "controls": {r: v for r, v in c.items() if v},
                     "gridSize": EXAMPLE["page"]["gridSize"]},
            "oldPageNumber": page_no, "instances": copy.deepcopy(EXAMPLE["instances"]),
            "connectionCollections": [], "imageLibrary": [], "imageLibraryCollections": []}
    return page, {"inputs": len(inputs), "mes": mes, "extras": extras, "modes": list(modes), "sources_placed": len(sources)}


if __name__ == "__main__":
    args = sys.argv[1:]
    host, page_no = "192.168.2.223:8000", 27
    if "--host" in args:
        i = args.index("--host"); host = args[i + 1]; del args[i:i + 2]
    if "--page" in args:
        i = args.index("--page"); page_no = int(args[i + 1]); del args[i:i + 2]
    out = args[0] if args else os.path.join(PROJECT, "atem-me-kit", "atem-sources-plusxl-v1.companionconfig")
    page, info = build(host, page_no)
    open(out, "wb").write(gzip.compress(json.dumps(page).encode()))
    print(f"wrote {out}: {sum(len(r) for r in page['page']['controls'].values())} keys | {info}")
