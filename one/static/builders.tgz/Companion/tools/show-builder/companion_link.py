"""Send a built page straight into a running Companion 5, through the same
import path the web UI uses (tRPC over the /trpc websocket):

    importExport.prepareImport.start / uploadChunk / complete  (SHA-1 checked)
    importExport.importSinglePage {sourcePage, targetPage, connectionIdRemapping}

It is an import, not a database write - Companion validates and applies it
exactly as if the file had been chosen in Settings > Import/Export. Verified
against Companion v5.0.6 (companion/lib/ImportExport/Controller.ts and the
web UI bundle). Standard library only: a minimal RFC 6455 client.
"""
import base64, hashlib, json, os, socket, struct, time


class WebSocket:
    def __init__(self, host, port, path="/trpc", timeout=10):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
               f"Origin: http://{host}:{port}\r\n\r\n")
        self.sock.sendall(req.encode())
        head = b""
        while b"\r\n\r\n" not in head:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("Companion closed the connection during the handshake")
            head += chunk
        status = head.split(b"\r\n", 1)[0]
        if b" 101 " not in status:
            raise ConnectionError(f"websocket upgrade refused: {status.decode(errors='replace')}")
        self.buf = head.split(b"\r\n\r\n", 1)[1]

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("Companion closed the connection")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def _frame(self, opcode, payload):
        head = bytes([0x80 | opcode])
        n = len(payload)
        if n < 126:
            head += bytes([0x80 | n])
        elif n < 65536:
            head += bytes([0x80 | 126]) + struct.pack("!H", n)
        else:
            head += bytes([0x80 | 127]) + struct.pack("!Q", n)
        mask = os.urandom(4)
        self.sock.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def send(self, obj):
        self._frame(0x1, json.dumps(obj).encode())

    def recv(self):
        """Next text message as JSON (answers pings, reassembles fragments)."""
        parts = []
        while True:
            b1, b2 = self._read(2)
            op, n = b1 & 0x0F, b2 & 0x7F
            if n == 126:
                n = struct.unpack("!H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack("!Q", self._read(8))[0]
            mask = self._read(4) if b2 & 0x80 else None
            data = self._read(n)
            if mask:
                data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
            if op == 0x9:
                self._frame(0xA, data)
                continue
            if op == 0x8:
                raise ConnectionError("Companion closed the connection")
            if op in (0x1, 0x0, 0x2):
                parts.append(data)
                if b1 & 0x80:
                    return json.loads(b"".join(parts))

    def close(self):
        try:
            self._frame(0x8, b"")
        except OSError:
            pass
        self.sock.close()


class Trpc:
    def __init__(self, host, port=8000):
        self.ws = WebSocket(host, port)
        self.next_id = 1

    def _wait(self, rid, deadline):
        while time.time() < deadline:
            msg = self.ws.recv()
            if msg.get("id") != rid:
                continue
            if "error" in msg:
                err = msg["error"]
                raise RuntimeError((err.get("message") if isinstance(err, dict) else None) or json.dumps(err))
            res = msg.get("result", {})
            if res.get("type") in ("started", "stopped"):
                continue
            return res.get("data")
        raise TimeoutError("no answer from Companion")

    def call(self, path, payload=None, timeout=30):
        rid, self.next_id = self.next_id, self.next_id + 1
        params = {"path": path}
        if payload is not None:
            params["input"] = payload
        self.ws.send({"id": rid, "method": "mutation", "params": params})
        return self._wait(rid, time.time() + timeout)

    def snapshot(self, path, timeout=10):
        """First value a subscription publishes, then unsubscribe."""
        rid, self.next_id = self.next_id, self.next_id + 1
        self.ws.send({"id": rid, "method": "subscription", "params": {"path": path}})
        data = self._wait(rid, time.time() + timeout)
        self.ws.send({"id": rid, "method": "subscription.stop"})
        return data

    def close(self):
        self.ws.close()


def _collect_init(data):
    """Watch subscriptions start with an 'init' message; accept either shape."""
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("type") == "init":
                return item.get("info") or item.get("data") or {}
        return {}
    if isinstance(data, dict):
        if data.get("type") == "init":
            return data.get("info") or data.get("data") or {}
        return data
    return {}


def split_host(hostport):
    host, _, port = hostport.partition(":")
    return host, int(port or 8000)


def connections(hostport):
    t = Trpc(*split_host(hostport))
    try:
        info = _collect_init(t.snapshot("instances.connections.watch"))
    finally:
        t.close()
    return {cid: {"moduleId": c.get("moduleId"), "label": c.get("label")}
            for cid, c in info.items() if isinstance(c, dict)}


def atem_connection(hostport, prefer="ATEM"):
    """(id, label) of the ATEM connection: the one labelled `prefer`, else the first."""
    atem = [(cid, c["label"]) for cid, c in connections(hostport).items() if c.get("moduleId") == "bmd-atem"]
    if not atem:
        raise RuntimeError("this Companion has no ATEM connection")
    return next((a for a in atem if a[1] == prefer), atem[0])


def _connection_config(t, cid):
    rid, t.next_id = t.next_id, t.next_id + 1
    t.ws.send({"id": rid, "method": "subscription",
               "params": {"path": "instances.connections.watchEdit", "input": {"connectionId": cid}}})
    data = t._wait(rid, time.time() + 8)
    t.ws.send({"id": rid, "method": "subscription.stop"})
    return data.get("config") or {}


def atem_fade_fps(hostport, prefer="ATEM"):
    cid, label = atem_connection(hostport, prefer)
    t = Trpc(*split_host(hostport))
    try:
        return {"label": label, "fps": _connection_config(t, cid).get("fadeFps")}
    finally:
        t.close()


def set_atem_fade_fps(hostport, fps, prefer="ATEM"):
    """Changes only the frame rate, keeping the rest of the connection's settings. Companion
    restarts the connection when it saves, so the switcher link drops for a moment."""
    cid, label = atem_connection(hostport, prefer)
    t = Trpc(*split_host(hostport))
    try:
        cfg = dict(_connection_config(t, cid))
        if "fadeFps" not in cfg and not cfg:
            raise RuntimeError("Companion didn't return the ATEM connection's settings")
        cfg["fadeFps"] = int(fps)
        err = t.call("instances.connections.setConfig", {"connectionId": cid, "label": label, "config": cfg})
        if err:
            raise RuntimeError(str(err))
        return {"label": label, "fps": _connection_config(t, cid).get("fadeFps")}
    finally:
        t.close()


def pages(hostport):
    """[{n, name, keys}] in page order, from the live Companion."""
    t = Trpc(*split_host(hostport))
    try:
        data = t.snapshot("pages.watch")
    finally:
        t.close()
    order, info = data.get("order", []), data.get("pages", {})
    out = []
    for n, pid in enumerate(order, start=1):
        pg = info.get(pid) or {}
        keys = sum(len(row) for row in (pg.get("controls") or {}).values())
        out.append({"n": n, "name": pg.get("name") or "", "keys": keys})
    return out


def remap(file_conns, target_conns):
    """Same rule as the Companion import dialog: same module + same label wins,
    else the first connection of that module; the id itself if it exists."""
    out = {}
    for fid, fc in (file_conns or {}).items():
        if not fc:
            continue
        if fid in target_conns and target_conns[fid]["moduleId"] == fc.get("moduleId"):
            out[fid] = fid
            continue
        same = [cid for cid, c in target_conns.items() if c["moduleId"] == fc.get("moduleId")]
        labelled = [cid for cid in same if target_conns[cid]["label"] == fc.get("label")]
        out[fid] = (labelled or same or [""])[0]
    return out


def send_page(hostport, page_bytes, target_page, name="show-builder.companionconfig"):
    """Import one page file onto `target_page` (replaces that page), or append
    a new page with target_page=-1. Returns (mapping used, Companion's reply)."""
    target_conns = connections(hostport)
    t = Trpc(*split_host(hostport))
    try:
        sid = t.call("importExport.prepareImport.start", {"name": name, "size": len(page_bytes)})
        if not sid:
            raise RuntimeError("Companion refused the upload")
        step = 1024 * 1024
        for off in range(0, len(page_bytes), step):
            ok = t.call("importExport.prepareImport.uploadChunk",
                        {"sessionId": sid, "offset": off,
                         "data": base64.b64encode(page_bytes[off:off + step]).decode()})
            if not ok:
                raise RuntimeError(f"upload failed at byte {off}")
        err, info = t.call("importExport.prepareImport.complete",
                           {"sessionId": sid, "expectedChecksum": hashlib.sha1(page_bytes).hexdigest(),
                            "userData": None}, timeout=60)
        if err or not info:
            raise RuntimeError(err or "Companion could not read the page")
        if info.get("type") != "page":
            raise RuntimeError(f"expected a page file, Companion saw '{info.get('type')}'")
        mapping = remap(info.get("connections"), target_conns)
        missing = [f"{(info['connections'][k] or {}).get('label')} ({(info['connections'][k] or {}).get('moduleId')})"
                   for k, v in mapping.items() if not v]
        if missing:
            t.call("importExport.abort")
            raise RuntimeError("this Companion has no connection for: " + ", ".join(missing))
        reply = t.call("importExport.importSinglePage",
                       {"sourcePage": 1, "targetPage": int(target_page), "connectionIdRemapping": mapping},
                       timeout=60)
        return mapping, reply
    finally:
        t.close()


# ---------------------------------------------------------------- connection presets
# instances.definitions.presets (no input) -> {type:"init", definitions: {connId: {catId: {name, order,
#   (newer Companion wraps each connection: {connId: {supportsReferences, sections: {catId: ...}}})
#   definitions: {groupId: simple {presets:{id:{label,order}}} | template {definition:{id,label},
#   templateVariableName, templateValues:[{label,value}]}}}}}}
# preview.graphics.preset {connectionId, presetId, variableValues|null} -> data:image/png (async; first data may be null)
# controls.importPreset {connectionId, presetId, location:{pageNumber,column,row}, variableValues} places one live.

def preset_catalog(hostport):
    conns = connections(hostport)
    t = Trpc(*split_host(hostport))
    try:
        data = t.snapshot("instances.definitions.presets", timeout=20)
    finally:
        t.close()
    out = []
    for cid, cats in (data.get("definitions") or {}).items():
        if isinstance(cats, dict) and isinstance(cats.get("sections"), dict):
            cats = cats["sections"]      # newer Companion: {supportsReferences, sections: {catId: ...}}
        c = conns.get(cid, {})
        entry = {"connectionId": cid, "label": c.get("label", cid), "moduleId": c.get("moduleId", "?"), "categories": []}
        for cat in sorted(cats.values(), key=lambda x: x.get("order", 0)):
            items = []
            for g in sorted((cat.get("definitions") or {}).values(), key=lambda x: x.get("order", 0)):
                if g.get("type") == "template":
                    d, var = g.get("definition") or {}, g.get("templateVariableName")
                    for tv in g.get("templateValues") or []:
                        items.append({"presetId": d.get("id"), "label": tv.get("label") or d.get("label"),
                                      "group": g.get("name") or "", "vars": {var: tv.get("value")} if var else None})
                else:
                    for p in sorted((g.get("presets") or {}).values(), key=lambda x: x.get("order", 0)):
                        items.append({"presetId": p.get("id"), "label": p.get("label"), "group": g.get("name") or "",
                                      "vars": None})
            if items:
                entry["categories"].append({"name": cat.get("name") or cat.get("id"), "items": items})
        if entry["categories"]:
            out.append(entry)
    return sorted(out, key=lambda e: e["label"].lower())


class PreviewSource:
    """One long-lived socket for preset previews (a page of tiles is dozens of requests)."""

    def __init__(self, hostport):
        self.hostport, self.t = hostport, None

    def get(self, connection_id, preset_id, variable_values, timeout=6):
        for attempt in (1, 2):
            try:
                if self.t is None:
                    self.t = Trpc(*split_host(self.hostport))
                t = self.t
                rid, t.next_id = t.next_id, t.next_id + 1
                t.ws.send({"id": rid, "method": "subscription", "params": {"path": "preview.graphics.preset",
                           "input": {"connectionId": connection_id, "presetId": preset_id,
                                     "variableValues": variable_values}}})
                end, got = time.time() + timeout, None
                while time.time() < end:
                    m = t.ws.recv()
                    if m.get("id") != rid:
                        continue
                    if "error" in m:
                        break
                    d = (m.get("result") or {}).get("data")
                    if isinstance(d, str) and d.startswith("data:image"):
                        got = d
                        break
                t.ws.send({"id": rid, "method": "subscription.stop"})
                return got
            except (OSError, ConnectionError, ValueError):
                self.close()
        return None

    def close(self):
        if self.t:
            try:
                self.t.close()
            except OSError:
                pass
        self.t = None


def import_presets(hostport, page_number, placements):
    """placements: [{row, column, connectionId, presetId, vars}] -> errors list (empty = all placed)."""
    errors = []
    if not placements:
        return errors
    t = Trpc(*split_host(hostport))
    try:
        for p in placements:
            try:
                t.call("controls.importPreset", {"connectionId": p["connectionId"], "presetId": p["presetId"],
                                                 "location": {"pageNumber": int(page_number), "column": int(p["column"]),
                                                              "row": int(p["row"])},
                                                 "variableValues": p.get("vars")})
            except Exception as e:  # noqa: BLE001 - report per key, keep placing the rest
                errors.append(f"{p['row']}/{p['column']} {p.get('label') or p['presetId']}: {e}")
    finally:
        t.close()
    return errors
