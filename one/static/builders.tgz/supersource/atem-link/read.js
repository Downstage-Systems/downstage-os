#!/usr/bin/env node
// Reads a switcher's state over the network and prints it as JSON. Read only: it connects, takes the state
// the ATEM sends every new client, and disconnects. It sends the switcher no commands.
//   node read.js <ip> [port]      exit 0 = JSON on stdout, 2 = couldn't connect
const { Atem } = require('atem-connection')
const [ip, port] = [process.argv[2], +process.argv[3] || 9910]
const atem = new Atem({ disableMultithreaded: true })
const fail = msg => { process.stderr.write(msg + '\n'); process.exit(2) }
const list = o => Object.values(o || {}).filter(Boolean)
const timer = setTimeout(() => fail(`No ATEM answered at ${ip}`), 8000)
atem.on('error', () => {})
atem.on('connected', () => {
  clearTimeout(timer)
  const s = atem.state
  const out = {
    product: s.info.productIdentifier, apiVersion: s.info.apiVersion, mes: s.info.capabilities.mixEffects,
    videoMode: s.settings.videoMode, inputs: list(s.inputs).map(i => ({ id: i.inputId, short: i.shortName, long: i.longName })),
    colors: (s.colorGenerators ? Object.entries(s.colorGenerators) : []).map(([index, c]) => c && { index: +index, ...c }).filter(Boolean),
    players: s.media.players.map((p, index) => p && { index, sourceType: p.sourceType, stillIndex: p.stillIndex, clipIndex: p.clipIndex }).filter(Boolean),
    stills: s.media.stillPool.map((f, index) => f && { index, used: f.isUsed, name: f.fileName }).filter(Boolean),
    stillCount: s.info.mediaPool ? s.info.mediaPool.stillCount : s.media.stillPool.length,
    macros: s.macro.macroProperties.map((m, index) => m && { index, used: m.isUsed, name: m.name, description: m.description }).filter(Boolean),
    superSources: s.video.superSources.map((ss, index) => ss && { index, ...ss.properties, boxes: ss.boxes }).filter(Boolean),
  }
  process.stdout.write(JSON.stringify(out), () => atem.disconnect().finally(() => process.exit(0)))
})
atem.connect(ip, port).catch(e => fail(String(e.message || e)))
