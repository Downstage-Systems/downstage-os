#!/usr/bin/env python3
"""SuperSource Builder - lay out a SuperSource 1-4 box look on your own background,
preview every move, and export everything a show needs.

    python3 twobox/server.py [--port 8788] [--no-browser]

Local only (127.0.0.1). Nothing here talks to a switcher or to Companion: it
writes files you load yourself (ATEM Software Control > File > Restore, Macros
only; the background PNG into the media pool; the .companionconfig into
Companion).

The engine is ../ss_anim.py; the Companion looks page comes from
../../Companion/tools/atem-ss-looks-page.py when that project is present.
"""
import urllib.parse, urllib.request
import argparse, base64, gzip, importlib.util, json, os, re, shutil, socket, socketserver, subprocess, sys, threading, time, webbrowser
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                                   # ATEM SS Builder/
DATA = os.environ.get("DOWNSTAGE_DATA") or ROOT                # set by the native app: its bundle is read-only, user files live here
PROFILES = os.path.join(DATA, "profiles")
SHOWS = os.path.join(DATA, "shows")
TEMPLATES = os.path.join(DATA, "templates")
LAYOUTS = os.path.join(DATA, "layouts")
EXPORTS = os.path.join(DATA, "exports")
FONTS = {"Rajdhani-Bold.ttf", "ShareTechMono-Regular.ttf", "Inter-Regular.ttf"}
COMPANION_TOOL = os.path.join(os.path.dirname(ROOT), "Companion", "tools", "atem-ss-looks-page.py")
for d in (PROFILES, SHOWS, EXPORTS, TEMPLATES, LAYOUTS):
    os.makedirs(d, exist_ok=True)

# the app ships a starter template and layout: copied once, never over the user's own
if DATA != ROOT:
    for d in (TEMPLATES, LAYOUTS):
        seed = os.path.join(ROOT, "seed", os.path.basename(d))
        if os.path.isdir(seed) and not os.listdir(d):
            for f in os.listdir(seed):
                shutil.copy(os.path.join(seed, f), d)

sys.path.insert(0, ROOT)
import ss_anim  # noqa: E402
sys.path.insert(0, HERE)
import atem_read  # noqa: E402

TEMPLATE_NAME = "(preview only - no switcher loaded)"
TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<Profile majorVersion="2" minorVersion="1" product="Template">
    <SuperSources>
        <SuperSource index="0" artFillInput="3020" artKeyInput="3021" artOption="Background" artPreMultiplied="False" artClip="50" artGain="70" artInvertKey="False">
            <Boxes>
                <Box index="0" enabled="True" inputSource="1" xPosition="-4.5" yPosition="-2.35" size="0.694" cropped="False" cropTop="0" cropBottom="0" cropLeft="0" cropRight="0"/>
                <Box index="1" enabled="True" inputSource="2" xPosition="10.13" yPosition="5.53" size="0.339" cropped="False" cropTop="0" cropBottom="0" cropLeft="0" cropRight="0"/>
                <Box index="2" enabled="False" inputSource="0" xPosition="-8" yPosition="-4.5" size="0.5" cropped="False" cropTop="0" cropBottom="0" cropLeft="0" cropRight="0"/>
                <Box index="3" enabled="False" inputSource="0" xPosition="8" yPosition="-4.5" size="0.5" cropped="False" cropTop="0" cropBottom="0" cropLeft="0" cropRight="0"/>
            </Boxes>
        </SuperSource>
    </SuperSources>
    <ColorGenerators>
        <ColorGenerator index="0" hue="0" saturation="0" luma="100"/>
        <ColorGenerator index="1" hue="0" saturation="0" luma="0"/>
    </ColorGenerators>
    <VideoMode videoMode="1080p2997"/>
    <Settings>
        <Inputs>""" + "".join(f'\n            <Input id="{n}" shortName="CAM{n}" longName="Camera {n}"/>' for n in range(1, 9)) + """
        </Inputs>
    </Settings>
    <MacroPool/>
</Profile>
"""
TEMPLATE_PATH = os.path.join(PROFILES, ".template.xml")
open(TEMPLATE_PATH, "w").write(TEMPLATE)


def slug(s):
    return re.sub(r"[^A-Za-z0-9._ -]+", "", s).strip() or "show"


# ---------------------------------------------------------------- switcher profiles

def profile_path(name):
    if not name or name == TEMPLATE_NAME:
        return TEMPLATE_PATH
    p = os.path.join(PROFILES, os.path.basename(name))
    if not os.path.isfile(p):
        raise ValueError(f"switcher export '{name}' not found in profiles/")
    return p


def hsl_hex(h, s, l):
    """ATEM colour generator (hue deg, sat %, luma %) -> #rrggbb, near enough for a preview."""
    import colorsys
    r, g, b = colorsys.hls_to_rgb((h % 360) / 360, l / 100, s / 100)
    return "#%02x%02x%02x" % (round(r * 255), round(g * 255), round(b * 255))


def profile_info(name):
    path = profile_path(name)
    root = ET.parse(path).getroot()
    ss, ver = ss_anim.find_supersource(root, 0)
    ops_ver, stem, _, crop_src = ss_anim.learn_op_names(root, ver)
    vm = root.find("VideoMode")
    mode = vm.get("videoMode", "") if vm is not None else ""
    names = {i.get("id"): (i.get("shortName") or "", i.get("longName") or "") for i in root.iter("Input")}
    inputs = [{"id": int(k), "short": v[0] or f"IN{k}", "long": v[1]} for k, v in names.items() if k.isdigit()]
    inputs.sort(key=lambda i: i["id"])
    colors = {}
    for cg in root.iter("ColorGenerator"):
        n = int(cg.get("index")) + 1
        colors[f"Color{n}"] = hsl_hex(float(cg.get("hue", 0)), float(cg.get("saturation", 0)), float(cg.get("luma", 0)))
    boxes = [dict(ss_anim.read_box(ss, i), index=i + 1) for i in range(4)]
    macros = [{"slot": int(m.get("index")) + 1, "name": m.get("name")} for m in root.iter("Macro")]
    art = ss.get("artFillInput")
    players = [{"index": int(m.get("index")), "type": m.get("sourceType"), "still": int(m.get("sourceIndex", 0)) + 1}
               for m in root.iter("MediaPlayer")]
    stills = [{"slot": int(s.get("index")) + 1, "name": s.get("name")} for s in root.iter("Still")]
    art_player = (int(art) - 3000) // 10 - 1 if art and art.isdigit() and 3000 < int(art) < 4000 else None
    art_still = next((p["still"] for p in players if p["index"] == art_player and p["type"] == "Still"), None)
    pool = max([20] + [s["slot"] for s in stills])
    ours = re.compile(r"SS\d? ")
    return {"name": TEMPLATE_NAME if path == TEMPLATE_PATH else os.path.basename(path),
            "template": path == TEMPLATE_PATH, "product": root.get("product", "?"), "mode": mode,
            "ops": ops_ver, "cropOps": f"{stem} ({crop_src})", "inputs": inputs, "colors": colors,
            "boxes": boxes, "macros": macros, "artFill": art, "players": players, "stills": stills,
            "artPlayer": art_player, "artStill": art_still, "poolSize": pool,
            "mes": max(1, len({m.get("index") for m in root.iter("MixEffectBlock")})),
            "live": root.get(atem_read.LIVE_ATTR), "liveAt": root.get("liveAt"),
            "otherMacros": sum(1 for m in macros if not ours.match(m["name"] or ""))}


def list_profiles():
    out = [TEMPLATE_NAME]
    for f in sorted(os.listdir(PROFILES), key=lambda f: -os.path.getmtime(os.path.join(PROFILES, f))):
        if f.endswith(".xml") and not f.startswith("."):
            out.append(f)
    return out


# ---------------------------------------------------------------- engine

def swap_slots(layout, info):
    """(look still, clean still, [fade stills strong→weak]), 1-based, or None when the background
    isn't swapped during moves. Fade stills = shadowFade - 1 extra slots (3 steps = 2 stills)."""
    if layout.get("style") == "fly":                 # rounded + fly-in: one still with rounded windows, never swapped
        return None
    baked = len(layout.get("boxes", [])) > 2 and float((layout.get("border") or {}).get("px", 0) or 0) > 0   # border painted into the art
    fr = layout.get("frame") or {}
    framed = fr.get("style", "none") != "none" and not fr.get("hidden")
    if not (layout.get("rounded") or (layout.get("artSwap") and ((layout.get("shadow") or {}).get("on") or baked or framed))):
        return None                                  # rounded corners always need the swap: rounded art home, clean while moving
    media = layout.get("media") or {}
    look = int(media.get("bgSlot") or info.get("artStill") or 1)
    taken = {look} | {int(e["slot"]) for e in media.get("extras", []) if e.get("slot")}
    clean = media.get("cleanSlot")
    if not clean:
        used = {s["slot"] for s in info.get("stills", [])}
        free = [s for s in range(1, info.get("poolSize", 20) + 1) if s not in taken and s not in used]
        clean = free[0] if free else next(s for s in range(1, 100) if s not in taken)
    clean = int(clean)
    n_fade = max(0, int(layout.get("shadowFade", 3) or 1) - 1)
    used = {s["slot"] for s in info.get("stills", [])}
    pool = info.get("poolSize", 20)
    fades = [s for s in range(1, pool + 1) if s not in taken | {clean} and s not in used][:n_fade]
    if len(fades) < n_fade:                      # not enough empty stills: reuse occupied ones above the rest
        fades += [s for s in range(pool, 0, -1) if s not in taken | {clean} | set(fades)][:n_fade - len(fades)]
    return look, clean, fades


def engine_args(layout, profile, info=None):
    argv = [profile]
    for n, b in enumerate(layout["boxes"], start=1):
        argv += ["--set", str(n)] + [f"{k}={float(b[k]):.8f}" for k in ("x", "y", "size")] + \
                [f"crop{c[0].upper()}={float(b.get(c, 0)):.8f}" for c in ("top", "bottom", "left", "right")]   # full precision - the engine rounds
        if b.get("input") not in (None, ""):
            argv.append(f"input={int(b['input'])}")
    n = len(layout["boxes"])
    cam = int(layout.get("cameraBox", 2 if n == 2 else 0) or 0)
    argv += ["--count", str(n), "--on-top", str(min(n, int(layout.get("onTop", 1) or 1))), "--exit", layout.get("exit", "auto"),
             "--frames", str(int(layout.get("frames", 15))), "--ease", layout.get("ease", "cubic"),
             "--step", str(int(layout.get("step", 1))),
             "--border-px", str(float(layout.get("border", {}).get("px", 4))),
             "--border-src", layout.get("border", {}).get("src", "Black"),
             "--art-mode", "swap" if layout.get("rounded") and layout.get("style") != "fly" else "background",
                                                    # builder art is a full background under the boxes; rounded corners:
                                                    # in front (rounded windows) when home, behind while moving
             "--camera", str(cam if cam <= n else 0), "--me", str(int(layout.get("me", 1)))]
    if layout.get("clear", n > 2):                  # other boxes slide out of the way (default with 3-4 boxes)
        argv.append("--clear")
    if layout.get("style") == "fly":                 # rounded + fly-in: keyers 1-4 each hold a source and a side
        src = lambda v: str(v) if str(v).startswith("b") else str(int(v))       # "b2" = follows whatever is in box 2
        keys = [f"{i + 1}:{src(k['src'])}:{'L' if k.get('side') == 'L' else 'R'}"
                for i, k in enumerate((layout.get("fly") or {}).get("keys") or []) if k and k.get("src") not in (None, "")]
        if keys:
            argv += ["--fly", ",".join(keys), "--fly-rate", str(int(layout.get("frames", 15)))]
    sw = swap_slots(layout, info or {})
    if sw:
        argv += ["--art-swap", str(sw[0]), str(sw[1])]
        if sw[2]:
            argv += ["--art-fade"] + [str(s) for s in sw[2]]
        sh = layout.get("shadow") or {}               # how far the baked shadow shows past a box edge (ambient layer)
        reach = max(10.0, float(sh.get('off', 6)) + 1.7 * float(sh.get('blur', 16))) if sh.get("on") else 1e9
        if (len(layout["boxes"]) > 2 or layout.get("rounded")) and float((layout.get("border") or {}).get("px", 0) or 0) > 0:
            # a painted border is a hard edge: only show it once each box is within a border's width of home
            reach = min(reach, max(8.0, 2 * float(layout["border"]["px"])))
        fr = layout.get("frame") or {}
        if fr.get("style", "none") != "none" and not fr.get("hidden"):         # a frame is a hard edge too: it shows only once each box is nearly home
            reach = min(reach, max(8.0, float(fr.get("gap", 6) or 0)))
        argv += ["--shadow-reach", f"{reach:.1f}"]
    return ss_anim.make_parser().parse_args(argv)


def run_engine(layout):
    path = profile_path(layout.get("profile"))
    info = profile_info(layout.get("profile"))
    args = engine_args(layout, path, info)
    r = ss_anim.build(args)
    notes = ss_anim.check_layout(r["home"], args.border)
    macros = [{"slot": i + 1, "name": n, "ops": len(o.lines), "replaced": n in r["replaced"]}
              for i, (n, o, _) in zip(r["slots"], r["macros"])]
    sw = swap_slots(layout, info)
    return r, args, {"variant": ss_anim.variant(r), "notes": notes, "macros": macros, "swap": sw,
                     "fps": args.fps, "product": r["product"], "picSlots": r["pic_slots"],
                     "borderOf": {str(k): v for k, v in args.border_of.items()}}


def save_data_url(url, path):
    head, _, data = url.partition(",")
    open(path, "wb").write(base64.b64decode(data))


def hex_hsl(hexc):
    """#rrggbb -> (hue 0-360, saturation 0-100, luma 0-100) as the profile's ColorGenerator stores them
    (the inverse of hsl_hex, so the switcher shows what the builder showed)."""
    import colorsys
    r, g, b = (int(hexc[i:i + 2], 16) / 255 for i in (1, 3, 5))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    return round(h * 360, 1), round(s * 100, 1), round(l * 100, 1)


def with_border_color(text, layout):
    """Border plates fed from Color 1/2: put the builder's border colour on that colour generator."""
    b = layout.get("border") or {}
    src, col = b.get("src"), b.get("color")
    if not col or src not in ("Color1", "Color2") or not float(b.get("px") or 0):
        return text
    h, s, l = hex_hsl(col)
    idx = int(src[-1]) - 1
    new = f'<ColorGenerator index="{idx}" hue="{h:g}" saturation="{s:g}" luma="{l:g}"/>'
    if re.search(r'<ColorGenerator index="%d"[^>]*/>' % idx, text):
        return re.sub(r'<ColorGenerator index="%d"[^>]*/>' % idx, new, text, count=1)
    return text


def with_media(text, stills, player=None, player_still=None):
    """Point the profile's media pool at our own files (ATEM Software Control reads
    <Still path="ATEM Media Pool/x.png"> relative to the .xml on Restore), and set
    the art's media player to the background still."""
    entries = "".join(f'\n            <Still index="{s - 1}" name="{html_attr(n)}" path="ATEM Media Pool/{html_attr(f)}"/>'
                      for s, n, f in sorted(stills))
    body = f"<Stills>{entries}\n        </Stills>"
    if re.search(r"<Stills>.*?</Stills>|<Stills\s*/>", text, re.S):
        text = re.sub(r"<Stills>.*?</Stills>|<Stills\s*/>", lambda m: body, text, count=1, flags=re.S)
    elif "<MediaPool>" in text:
        text = text.replace("<MediaPool>", "<MediaPool>\n        " + body, 1)
    else:
        text = text.replace("</Profile>", f"    <MediaPool>\n        {body}\n    </MediaPool>\n</Profile>", 1)
    if player is not None and player_still:
        text = re.sub(r'<MediaPlayer index="%d"[^>]*/>' % player,
                      f'<MediaPlayer index="{player}" sourceType="Still" sourceIndex="{player_still - 1}"/>', text, count=1)
    return text


def html_attr(s):
    return str(s).replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


def save_overlay(layout, overlay, background=False):
    """The whole graphic with clear (transparent) windows, like a designer's template."""
    name = slug(layout.get("name") or "show")
    out = os.path.join(EXPORTS, name)
    os.makedirs(out, exist_ok=True)
    p = os.path.join(out, f"{name} background only.png" if background else f"{name} {len(layout.get('boxes') or [0, 0])}-box overlay.png")
    save_data_url(overlay, p)
    return p


def export(layout, background, guide, clean=None, overlay=None, fades=None):
    if not layout.get("profile") or layout.get("profile") == TEMPLATE_NAME:
        raise ValueError("Read the switcher by IP or load its export first (Switcher). The macro file has to be "
                         "built for that switcher so existing macros keep their slots.")
    name = slug(layout.get("name") or "show")
    out = os.path.join(EXPORTS, name)
    os.makedirs(out, exist_ok=True)
    r, args, info = run_engine(layout)
    files = []
    info_p = profile_info(layout["profile"])
    media = layout.get("media") or {}
    pool_dir = os.path.join(out, "ATEM Media Pool")
    os.makedirs(pool_dir, exist_ok=True)
    stills = []                                     # (slot, name, file)
    bg_slot = media.get("bgSlot") or info_p["artStill"]
    if background and bg_slot:
        f = f"{name} background.png"
        save_data_url(background, os.path.join(pool_dir, f))
        stills.append((int(bg_slot), f"{name} BG"[:40], f))
    sw = info.get("swap")
    if sw and clean:
        f = f"{name} background clean.png"
        save_data_url(clean, os.path.join(pool_dir, f))
        stills.append((sw[1], f"{name} BG clean"[:40], f))
        for n, (slot, data) in enumerate(zip(sw[2], fades or []), start=1):
            f = f"{name} background fade {n}.png"
            save_data_url(data, os.path.join(pool_dir, f))
            stills.append((slot, f"{name} BG fade {n}"[:40], f))
    for ex in media.get("extras", []):
        if ex.get("image") and ex.get("slot"):
            f = slug(ex.get("name") or f"still {ex['slot']}") + ".png"
            save_data_url(ex["image"], os.path.join(pool_dir, f))
            stills.append((int(ex["slot"]), (ex.get("name") or f)[:40], f))
    slots = [s for s, _, _ in stills]
    if len(slots) != len(set(slots)):
        raise ValueError("two stills are set to the same media pool slot")
    text = with_media(r["text"], stills, info_p["artPlayer"], int(bg_slot) if bg_slot else None)
    text = with_border_color(text, layout)
    if info_p.get("live"):
        text = atem_read.clean_export(text)
    xml = os.path.join(out, f"{name} SS ANIM.xml")
    open(xml, "w", encoding="utf-8").write(text)
    files.append(xml)
    files += [os.path.join("ATEM Media Pool", f) for _, _, f in stills]
    prev = os.path.join(out, f"{name} preview.html")
    ss_anim.write_preview(prev, [ss_anim.variant(r, name, "Every frame is what the macro sets on the switcher.")])
    files.append(prev)
    if background:
        p = os.path.join(out, f"{name} background.png")
        save_data_url(background, p)
        files.append(p)
    if guide:
        p = os.path.join(out, f"{name} layout guide.png")
        save_data_url(guide, p)
        files.append(p)
    if overlay:
        files.append(save_overlay(layout, overlay))
    show = os.path.join(out, f"{name}.2box.json")
    json.dump(layout, open(show, "w"))
    files.append(show)
    companion = None
    if os.path.isfile(COMPANION_TOOL):
        try:
            spec = importlib.util.spec_from_file_location("atem_ss_looks_page", COMPANION_TOOL)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            page, _, _ = mod.build(xml, 1, f"F{len(layout['boxes'])}" if layout.get("style") == "fly" else len(layout["boxes"]))
            p = os.path.join(out, f"{name} SS LOOKS.companionconfig")
            open(p, "wb").write(gzip.compress(json.dumps(page).encode()))
            files.append(p)
            companion = p
        except SystemExit as e:
            companion = f"skipped: {e}"
        except Exception as e:                                  # the rest of the export still stands
            companion = f"skipped: {e}"
    return {"folder": out, "files": [f if f.startswith("ATEM Media Pool") else os.path.basename(f) for f in files],
            "notes": info["notes"], "macros": info["macros"], "companion": companion, "live": info_p.get("live"), "otherMacros": info_p.get("otherMacros", 0),
            "artFill": info_p["artFill"], "artPlayer": info_p["artPlayer"],
            "stills": [{"slot": s, "name": n} for s, n, _ in sorted(stills)], "bgSlot": bg_slot}


# ---------------------------------------------------------------- switcher and Companion links
def saved_link(key):
    try:
        return json.load(open(os.path.join(DATA, "links.json"))).get(key) or ""
    except (OSError, ValueError):
        return ""


def save_link(key, value):
    p = os.path.join(DATA, "links.json")
    try:
        d = json.load(open(p))
    except (OSError, ValueError):
        d = {}
    d[key] = value
    json.dump(d, open(p, "w"))


SIGNUP_URL = ""
signup_lock = threading.Lock()


def send_signup():
    return


def read_switcher(ip, port=9910):
    st = atem_read.read_state(ip, port)
    name = slug(f'{st.get("product") or "ATEM"} {ip}') + ".xml"
    text = atem_read.state_to_xml(st, ip, time.strftime("%b %-d %-I:%M %p"))
    ET.fromstring(text)
    open(os.path.join(PROFILES, name), "w", encoding="utf-8").write(text)
    save_link("switcher", ip)
    return profile_info(name)


def companion_link():
    p = os.path.join(os.path.dirname(COMPANION_TOOL), "show-builder", "companion_link.py")
    if not os.path.isfile(p):
        raise RuntimeError("The Companion link isn't installed")
    spec = importlib.util.spec_from_file_location("companion_link", p)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def companion_info(host):
    if not re.fullmatch(r"[A-Za-z0-9.-]+(:\d+)?", host or ""):
        raise ValueError("Enter Companion's address, like 192.168.1.20:8000")
    link = companion_link()
    try:
        conns, pages = link.connections(host), link.pages(host)
    except OSError as e:
        raise RuntimeError(f"Couldn't reach Companion at {host}. Is it running, with that address and port?") from e
    save_link("companion", host)
    return {"host": host, "pages": pages, "atem": [c["label"] for c in conns.values() if c.get("moduleId") == "bmd-atem"]}


def send_to_companion(host, name, target, atem):
    """Send an exported look's page. It goes in the way a file import does, so Companion checks it first."""
    p = os.path.realpath(os.path.join(EXPORTS, slug(name), f"{slug(name)} SS LOOKS.companionconfig"))
    if not p.startswith(os.path.realpath(EXPORTS) + os.sep) or not os.path.isfile(p):
        raise ValueError("Export this look first, then send it")
    page = json.loads(gzip.decompress(open(p, "rb").read()))
    link = companion_link()
    labels = [c["label"] for c in link.connections(host).values() if c.get("moduleId") == "bmd-atem"]
    if not labels:
        raise RuntimeError("This Companion has no ATEM connection. Add one, then send again")
    label = atem if atem in labels else "ATEM" if "ATEM" in labels else labels[0]
    if label != "ATEM":                                        # keys name the connection they read
        for inst in page.get("instances", {}).values():
            if isinstance(inst, dict) and inst.get("moduleId") == "bmd-atem":
                inst["label"] = label
        page = json.loads(json.dumps(page).replace("(ATEM:", f"({label}:"))
    target = int(target)
    link.send_page(host, gzip.compress(json.dumps(page).encode()), target, name=f"{slug(name)}.companionconfig")
    live = link.pages(host)
    landed = target if target > 0 else len(live)
    return {"page": landed, "pages": live, "atem": label, "now": next((x for x in live if x["n"] == landed), None)}


# ---------------------------------------------------------------- shows

def list_shows():
    out = []
    for f in sorted(os.listdir(SHOWS), key=lambda f: -os.path.getmtime(os.path.join(SHOWS, f))):
        if f.endswith(".2box.json") and not f.startswith("_"):
            out.append({"name": f[:-10], "at": time.strftime("%Y-%m-%d %H:%M",
                                                             time.localtime(os.path.getmtime(os.path.join(SHOWS, f))))})
    return out


def list_templates():
    out = []
    for f in sorted(os.listdir(TEMPLATES), key=lambda f: -os.path.getmtime(os.path.join(TEMPLATES, f))):
        if f.endswith(".2boxtpl.json"):
            try:
                d = json.load(open(os.path.join(TEMPLATES, f)))
            except Exception:
                continue
            out.append({"name": d.get("name") or f[:-13], "file": f[:-13], "thumb": d.get("thumb"), "note": d.get("note", ""),
                        "at": time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(os.path.join(TEMPLATES, f))))})
    return out


# ---------------------------------------------------------------- http

def show_builder():
    """Where to open Show Builder on this Mac: its app if it's here, else its running page. None if neither."""
    docs = os.path.expanduser("~/Documents/Downstage Systems/Companion")
    native = [t for t in ("/Applications/Downstage Show Builder.app", os.path.join(docs, "dist", "Downstage Show Builder.app")) if os.path.isdir(t)]
    def running(port):
        with socket.socket() as c:
            c.settimeout(0.2)
            return c.connect_ex(("127.0.0.1", port)) == 0
    if native and running(8786):
        return native[0]                       # brings its window forward
    if running(8787):
        return "http://127.0.0.1:8787/"        # the copy started from Companion/Show Builder.app
    dev = os.path.join(docs, "Show Builder.app")
    return native[0] if native else dev if os.path.isdir(dev) else None


BUILDER_IDLE = int(os.environ.get("DOWNSTAGE_BUILDER_IDLE") or 600)
last_request = [time.time()]
def idle_watch():
    while True:
        time.sleep(min(10, BUILDER_IDLE))
        if time.time() - last_request[0] > BUILDER_IDLE:
            os._exit(0)
threading.Thread(target=idle_watch, daemon=True).start()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        if not isinstance(body, (bytes, bytearray)):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        last_request[0] = time.time()
        if self.path == "/api/alive":
            return self.send(200, {"ok": True})
        try:
            if self.path in ("/", "/index.html"):
                return self.send(200, open(os.path.join(HERE, "index.html"), "rb").read(), "text/html; charset=utf-8")
            if self.path.startswith("/fonts/"):
                f = os.path.basename(self.path)
                if f in FONTS:
                    for d in (os.path.join(ROOT, "fonts"), os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"):
                        if os.path.isfile(os.path.join(d, f)):
                            return self.send(200, open(os.path.join(d, f), "rb").read(), "font/ttf")
                return self.send(404, {"error": "font not installed"})
            if self.path == "/app-icon.png":
                return self.send(200, open(os.path.join(HERE, "app-icon.png"), "rb").read(), "image/png")
            if self.path == "/api/autosave":
                p = os.path.join(SHOWS, "_last.2box.json")
                if not os.path.isfile(p):
                    return self.send(200, {"layout": None})
                return self.send(200, {"layout": json.load(open(p)),
                                       "at": time.strftime("%a %b %-d, %-I:%M %p", time.localtime(os.path.getmtime(p)))})
            if self.path.startswith("/api/exportzip?"):
                import io, zipfile
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                n = slug((q.get("name") or [""])[0])
                top = os.path.join(EXPORTS, n)
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
                    for d, _, fs in os.walk(top):
                        for f in fs:
                            p = os.path.join(d, f)
                            z.write(p, os.path.join(n, os.path.relpath(p, top)))
                data = buf.getvalue()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(n + ".zip"))
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            if self.path == "/api/meta":
                return self.send(200, {"profiles": list_profiles(), "shows": list_shows(),
                                       "companion": os.path.isfile(COMPANION_TOOL), "root": DATA, "showBuilder": True, "switcherIp": saved_link("switcher"), "companionHost": saved_link("companion"), "bonus": True})
            if self.path.startswith("/api/profile/"):
                return self.send(200, profile_info(self.path.split("/", 3)[3].replace("%20", " ")))
            if self.path == "/api/layouts":
                out = []
                for f in sorted(os.listdir(LAYOUTS), key=lambda f: os.path.getmtime(os.path.join(LAYOUTS, f))):
                    if f.endswith(".2boxlayout.json"):
                        try:
                            d = json.load(open(os.path.join(LAYOUTS, f)))
                            out.append({**d, "file": f[:-16]})
                        except Exception:
                            pass
                return self.send(200, out)
            if self.path == "/api/templates":
                return self.send(200, list_templates())
            if self.path.startswith("/api/templates/"):
                n = os.path.basename(self.path.split("/", 3)[3].replace("%20", " "))
                return self.send(200, json.load(open(os.path.join(TEMPLATES, n + ".2boxtpl.json"))))
            if self.path.startswith("/api/shows/"):
                n = os.path.basename(self.path.split("/", 3)[3].replace("%20", " "))
                return self.send(200, json.load(open(os.path.join(SHOWS, n + ".2box.json"))))
            return self.send(404, {"error": "not found"})
        except Exception as e:
            return self.send(500, {"error": str(e)})

    def do_POST(self):
        last_request[0] = time.time()
        try:
            b = self.body()
            if self.path == "/api/profile":
                ET.fromstring(b["xml"])                              # must parse
                name = slug(os.path.basename(b.get("name") or "switcher.xml"))
                if not name.endswith(".xml"):
                    name += ".xml"
                open(os.path.join(PROFILES, name), "w", encoding="utf-8").write(b["xml"])
                return self.send(200, profile_info(name))
            if self.path in ("/api/bonus/unlock", "/api/bonus/set"):
                return self.send(200, {"bonus": True})
            if self.path == "/api/profile/read":
                return self.send(200, read_switcher(str(b.get("ip") or "").strip(), int(b.get("port") or 9910)))
            if self.path == "/api/companion/info":
                return self.send(200, companion_info(str(b.get("host") or "").strip()))
            if self.path == "/api/companion/send":
                return self.send(200, send_to_companion(str(b["host"]).strip(), b["name"], b.get("target", -1), b.get("atem")))
            if self.path == "/api/build":
                return self.send(200, run_engine(b["layout"])[2])
            if self.path == "/api/layouts/save":
                n = slug(b.get("name") or "Layout")
                json.dump({"name": b.get("name") or n, "layout": b["layout"], "thumb": b.get("thumb")},
                          open(os.path.join(LAYOUTS, n + ".2boxlayout.json"), "w"))
                return self.send(200, {"ok": True, "file": n})
            if self.path == "/api/layouts/delete":
                p = os.path.join(LAYOUTS, os.path.basename(b["file"]) + ".2boxlayout.json")
                if os.path.isfile(p):
                    os.remove(p)
                return self.send(200, {"ok": True})
            if self.path == "/api/templates/save":
                n = slug(b.get("name") or "My template")
                json.dump({"name": b.get("name") or n, "note": b.get("note", ""), "thumb": b.get("thumb"),
                           "layout": b["layout"]}, open(os.path.join(TEMPLATES, n + ".2boxtpl.json"), "w"))
                return self.send(200, {"ok": True, "file": n, "templates": list_templates()})
            if self.path == "/api/templates/delete":
                p = os.path.join(TEMPLATES, os.path.basename(b["file"]) + ".2boxtpl.json")
                if os.path.isfile(p):
                    os.remove(p)
                return self.send(200, {"ok": True, "templates": list_templates()})
            if self.path == "/api/autosave":
                json.dump(b["layout"], open(os.path.join(SHOWS, "_last.2box.json"), "w"))
                return self.send(200, {"ok": True})
            if self.path == "/api/save":
                n = slug(b["layout"].get("name") or "show")
                json.dump(b["layout"], open(os.path.join(SHOWS, n + ".2box.json"), "w"))
                return self.send(200, {"ok": True, "name": n, "shows": list_shows()})
            if self.path == "/api/export":
                return self.send(200, export(b["layout"], b.get("background"), b.get("guide"), b.get("clean"), b.get("overlay"), b.get("fades")))
            if self.path == "/api/png":
                p = save_overlay(b["layout"], b["overlay"], bool(b.get("background")))
                return self.send(200, {"path": p, "folder": os.path.dirname(p), "file": os.path.basename(p)})
            if self.path == "/api/reveal":
                p = os.path.realpath(b["path"])
                if p.startswith(os.path.realpath(DATA)):
                    subprocess.Popen(["open", "-R", p] if os.path.isfile(p) else ["open", p])
                return self.send(200, {"ok": True})
            if self.path == "/api/open-show-builder":
                t = show_builder()
                if t:
                    subprocess.Popen(["open", t])
                return self.send(200, {"ok": bool(t)})
            if False:   # the One keeps it running
                self.send(200, {"ok": True})
                threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
                return
            return self.send(404, {"error": "not found"})
        except SystemExit as e:
            return self.send(400, {"error": str(e)})
        except Exception as e:
            return self.send(400, {"error": str(e)})


ThreadingHTTPServer.server_bind = socketserver.TCPServer.server_bind      # the stock one looks up this address's name, which took python.org's Python 35 s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8788)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    srv = ThreadingHTTPServer(("0.0.0.0", a.port), H)
    url = f"http://127.0.0.1:{a.port}/"
    print(f"SuperSource Builder on {url}")
    if not a.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
