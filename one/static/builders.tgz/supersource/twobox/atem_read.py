"""Read a switcher by IP and write it as a profile the builder can use, in the same shape as an ATEM
Software Control export. It carries names, layout and which slots are taken, but not the macros' contents:
those only come in a File > Save As export. Downstream code treats it like any other profile."""
import json, os, re, shutil, subprocess
from xml.sax.saxutils import quoteattr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HELPER = os.path.join(ROOT, "atem-link", "read.js")
NODE_PATHS = ["/opt/companion/node-runtimes/node22/bin/node", "/opt/companion/node-runtimes/main/bin/node"]
VIDEO_MODES = ["525i5994", "625i50", "525i5994", "625i50", "720p50", "720p5994", "1080i50", "1080i5994",
               "1080p2398", "1080p24", "1080p25", "1080p2997", "1080p50", "1080p5994",
               "4Kp2398", "4Kp24", "4Kp25", "4Kp2997", "4Kp50", "4Kp5994",
               "8Kp2398", "8Kp24", "8Kp25", "8Kp2997", "8Kp50", "8Kp5994", "1080p30", "1080p60"]
LIVE_ATTR = "liveFrom"


def read_state(ip, port=9910):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]{0,253}", ip or ""):
        raise ValueError("Enter the switcher's IP address, like 192.168.1.240")
    node = next((p for p in NODE_PATHS if os.path.isfile(p)), None) or shutil.which("node")
    if not node:
        raise RuntimeError("The part that talks to the switcher isn't installed (no Node runtime found)")
    r = subprocess.run([node, HELPER, ip, str(port)], capture_output=True, text=True, timeout=20)
    if r.returncode:
        raise RuntimeError((r.stderr.strip().splitlines() or [f"Couldn't read {ip}"])[-1])
    return json.loads(r.stdout.strip().splitlines()[-1])       # the library prints a notice first


def _num(v):
    return f"{v:g}"


def state_to_xml(st, ip, at):
    q = quoteattr
    mode = st.get("videoMode")
    mode = VIDEO_MODES[mode] if isinstance(mode, int) and 0 <= mode < len(VIDEO_MODES) else ""
    out = [f'<?xml version="1.0" encoding="UTF-8"?>\n<Profile majorVersion="2" minorVersion="1" product={q(st.get("product") or "ATEM")} '
           f'{LIVE_ATTR}={q(ip)} liveAt={q(at)}>',
           "    <MixEffectBlocks>" + "".join(f'<MixEffectBlock index="{i}"/>' for i in range(st.get("mes") or 1)) + "</MixEffectBlocks>",
           "    <ColorGenerators>" + "".join(f'<ColorGenerator index="{c["index"]}" hue="{_num(c["hue"] / 10)}" saturation="{_num(c["saturation"] / 10)}" luma="{_num(c["luma"] / 10)}"/>'
                                             for c in st.get("colors", [])) + "</ColorGenerators>",
           f'    <VideoMode videoMode="{mode}"/>', "    <Settings>", "        <Inputs>"]
    out += [f'            <Input id="{i["id"]}" shortName={q(i.get("short") or "")} longName={q(i.get("long") or "")}/>' for i in st.get("inputs", [])]
    out += ["        </Inputs>", "    </Settings>", "    <MediaPlayers>"]
    out += [f'        <MediaPlayer index="{p["index"]}" sourceType="{"Clip" if p["sourceType"] == 2 else "Still"}" '
            f'sourceIndex="{p["clipIndex"] if p["sourceType"] == 2 else p["stillIndex"]}"/>' for p in st.get("players", [])]
    out += ["    </MediaPlayers>", "    <SuperSources>"]
    for ss in st.get("superSources", []):
        out.append(f'        <SuperSource index="{ss["index"]}" artFillInput="{ss["artFillSource"]}" artKeyInput="{ss["artCutSource"]}" '
                   f'artOption="{"Foreground" if ss["artOption"] == 1 else "Background"}" artPreMultiplied="{ss["artPreMultiplied"]}" '
                   f'artClip="{_num(ss["artClip"] / 10)}" artGain="{_num(ss["artGain"] / 10)}" artInvertKey="{ss["artInvertKey"]}">')
        out.append("            <Boxes>")
        for i, b in enumerate(ss.get("boxes", [])):
            if b:
                out.append(f'                <Box index="{i}" enabled="{b["enabled"]}" inputSource="{b["source"]}" xPosition="{_num(b["x"] / 100)}" '
                           f'yPosition="{_num(b["y"] / 100)}" size="{_num(b["size"] / 1000)}" cropped="{b["cropped"]}" cropTop="{_num(b["cropTop"] / 1000)}" '
                           f'cropBottom="{_num(b["cropBottom"] / 1000)}" cropLeft="{_num(b["cropLeft"] / 1000)}" cropRight="{_num(b["cropRight"] / 1000)}"/>')
        out += ["            </Boxes>", "        </SuperSource>"]
    out += ["    </SuperSources>", "    <MediaPool>", "        <Stills>"]
    out += [f'            <Still index="{f["index"]}" name={q(f.get("name") or "Still " + str(f["index"] + 1))}/>' for f in st.get("stills", []) if f.get("used")]
    out += ["        </Stills>", "    </MediaPool>", "    <MacroPool>"]
    out += [f'        <Macro index="{m["index"]}" name={q(m.get("name") or "")} description={q(m.get("description") or "")}></Macro>'
            for m in st.get("macros", []) if m.get("used")]
    out += ["    </MacroPool>", "</Profile>", ""]
    return "\n".join(out)


def clean_export(text):
    """What a live read can't fill in must not reach a Restore file: a macro with no ops would blank the
    real one, and a still with no path has no picture to load."""
    text = re.sub(r"\n?\s*<Macro index=\"\d+\" name=\"[^\"]*\" description=\"[^\"]*\"></Macro>", "", text)
    text = re.sub(r"\n?\s*<Still index=\"\d+\" name=\"[^\"]*\"\s*/>", "", text)
    return re.sub(rf' (?:{LIVE_ATTR}|liveAt)="[^"]*"', "", text, count=2)
