#!/usr/bin/env python3
"""
ATEM SuperSource animation macro builder.

Reads an ATEM Software Control profile export (File > Save As .xml), takes two
SuperSource boxes as the "2 BOX" home look, and writes a copy of the profile
with animation macros added to the Macro Pool:

    SS 2BOX>FS1   SS FS1>2BOX
    SS 2BOX>FS2   SS FS2>2BOX
    SS FS1>FS2    SS FS2>FS1
    SS IN FS1>2BOX  SS IN FS1>FS2  SS IN FS2>2BOX  SS IN FS2>FS1
    SS 2BOX SETUP   (run once / any time: sources, borders, art, home look)

--count 1..4 makes a 1-, 3- or 4-picture look instead (home look "1BOX" / "3BOX" /
"4BOX", FS1..FSn, every FULL-to-FULL move, prefix "SS1 " / "SS3 " / "SS4 "). With
3 or 4 pictures every box is a picture, so there are no border plates - borders
are baked into the art like the shadow.

The IN macros start from something that is NOT SuperSource on program (a camera,
the graphics source): SuperSource snaps to that picture full screen off air, the
program bus cuts to SuperSource (an invisible cut - same picture), then the move
runs. Companion's look keys put the live camera into the camera box first.

Animation = one macro step per keyframe (x / y / size / crop) separated by
MacroSleep, eased in and out.

Borders (default on): the two spare SuperSource boxes become border plates fed
from a colour generator, sitting one layer under each picture box and cropped so
the border is the same width on every side. They move with their box on every
frame. Layer order becomes:
    box 1 = FS1 picture   box 2 = FS1 border
    box 3 = FS2 picture   box 4 = FS2 border
The art is then used in Background mode (no borders or windows needed in it).
With --border-px 0 the old behaviour is kept: two boxes, art flipped to
Background for the full-screen looks and back to Foreground for 2 BOX.

Restore on the switcher with File > Restore and tick ONLY "Macros", then run
"SS 2BOX SETUP" once.

Works with SuperSource V2 (Mini Extreme, Constellation) and V1
(2 M/E / 4 M/E Production/Broadcast Studio 4K) op naming. Detection is
automatic; recording a macro on the switcher that moves a box and changes a
crop lets the script copy that switcher's exact op names.
"""
import argparse
import html
import json
import math
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

HALF_W, HALF_H = 16.0, 9.0   # SuperSource frame is 32 x 18 units, centred on 0,0
PARK_X = 40.0                # off-frame for any box size (x range is +/-48)
PARK_Y = 26.0                # off-frame for any box size (y range is +/-27)
EXITS = {"left": ("x", -1), "right": ("x", 1), "down": ("y", -1), "up": ("y", 1)}
SLIDE_MARGIN = 0.5
PX_PER_UNIT = 60.0           # 1080 / 18 units
KEYS = ("x", "y", "size", "top", "bottom", "left", "right")
CROPS = ("top", "bottom", "left", "right")
FULL = {"x": 0.0, "y": 0.0, "size": 1.0, "top": 0.0, "bottom": 0.0, "left": 0.0, "right": 0.0}

EASES = {
    "linear": lambda t: t,
    "sine":   lambda t: -(math.cos(math.pi * t) - 1) / 2,
    "quad":   lambda t: 2 * t * t if t < 0.5 else 1 - (-2 * t + 2) ** 2 / 2,
    "cubic":  lambda t: 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2,
}


# ---------------------------------------------------------------- inputs

def input_name(src):
    """Profile input id -> macro input name."""
    s = str(src)
    if not s.isdigit():
        return s
    n = int(s)
    fixed = {0: "Black", 1000: "ColorBars", 6000: "SuperSource", 7001: "CleanFeed1", 7002: "CleanFeed2"}
    if n in fixed:
        return fixed[n]
    if 1 <= n <= 999:
        return f"Camera{n}"
    if 2001 <= n <= 2099:
        return f"Color{n - 2000}"
    if 3000 <= n <= 3999 and n % 10 == 0:
        return f"MediaPlayer{(n - 3000) // 10}"
    if 3000 <= n <= 3999 and n % 10 == 1:
        return f"MediaPlayer{(n - 3000) // 10}Key"
    if 6000 <= n <= 6099:
        return f"SuperSource{n - 6000 + 1}"
    if 10010 <= n <= 10999 and n % 10 in (0, 1):          # M/E outputs, as ATEM Software Control records them
        return f"ME{(n - 10000) // 10}{'Program' if n % 10 == 0 else 'Preview'}"
    if 7001 <= n <= 7009:
        return f"CleanFeed{n - 7000}"
    sys.exit(f"Don't know the macro name for input {n}; pass the name instead (e.g. Color2).")


def input_id(name):
    """Macro input name (or id) -> profile input id; inverse of input_name."""
    s = str(name)
    if s.isdigit():
        return int(s)
    fixed = {"Black": 0, "ColorBars": 1000, "SuperSource": 6000, "CleanFeed1": 7001, "CleanFeed2": 7002}
    if s in fixed:
        return fixed[s]
    for pat, f in ((r"Camera(\d+)$", lambda n: n), (r"Color(\d+)$", lambda n: 2000 + n),
                   (r"MediaPlayer(\d+)Key$", lambda n: 3001 + 10 * n), (r"MediaPlayer(\d+)$", lambda n: 3000 + 10 * n),
                   (r"SuperSource(\d+)$", lambda n: 5999 + n), (r"ME(\d+)Program$", lambda n: 10000 + 10 * n),
                   (r"ME(\d+)Preview$", lambda n: 10001 + 10 * n), (r"CleanFeed(\d+)$", lambda n: 7000 + n)):
        m = re.match(pat, s)
        if m:
            return f(int(m.group(1)))
    raise ValueError(f"unknown input {s}")


def write_layout(text, cfg, home, home_inputs):
    """Put the 2 BOX look into the profile's own SuperSource section, so restoring
    'SuperSource' sets the boxes, border plates and art option without running SETUP."""
    if cfg.ops_version == "v2":
        m = re.search(r'<SuperSource index="%d"[^>]*>.*?</SuperSource>' % cfg.ss, text, re.S)
    else:
        m = re.search(r'<SuperSource\b[^>]*>.*?</SuperSource>', text, re.S)
    if not m:
        return text
    block = m.group(0)
    boxes = {}
    for s, p in home.items():
        boxes[s] = (input_id(home_inputs[s]), p)
        if s in cfg.border_of:
            boxes[cfg.border_of[s]] = (input_id(cfg.border_src), border_of(p, cfg.border))
    for s, (src, p) in boxes.items():
        cropped = any(rnd(p[c], 2) for c in CROPS) or s in cfg.border_of.values()
        attrs = (f'index="{s}" enabled="True" inputSource="{src}" xPosition="{rnd(p["x"], 2) + 0.0:g}" '
                 f'yPosition="{rnd(p["y"], 2) + 0.0:g}" size="{rnd(p["size"], 3) + 0.0:g}" '
                 f'cropped="{cropped}" ' + " ".join(f'crop{c.capitalize()}="{rnd(p[c], 2) + 0.0:g}"' for c in CROPS))
        block = re.sub(r'<Box index="%d"[^>]*/>' % s, f"<Box {attrs}/>", block, count=1)
    for s in range(4):                                  # boxes this look doesn't use are switched off
        if s not in boxes:
            block = re.sub(r'(<Box index="%d"[^>]*?)enabled="True"' % s, r'\1enabled="False"', block, count=1)
    if cfg.art_mode == "background":
        block = re.sub(r'artOption="\w+"', 'artOption="Background"', block, count=1)
    elif cfg.art_mode in ("foreground", "swap"):        # rounded-window art in front of the boxes in the home look
        block = re.sub(r'artOption="\w+"', 'artOption="Foreground"', block, count=1)
        block = re.sub(r'artPreMultiplied="\w+"', 'artPreMultiplied="True"', block, count=1)
    return text[:m.start()] + block + text[m.end():]


# ---------------------------------------------------------------- profile read

def find_supersource(root, ss_index):
    """Return (SuperSource element, 'v1'|'v2')."""
    group = root.find("SuperSources")
    if group is not None:
        for ss in group.findall("SuperSource"):
            if int(ss.get("index", 0)) == ss_index:
                return ss, "v2"
        sys.exit(f"SuperSource index {ss_index} not found in profile.")
    ss = root.find("SuperSource")
    if ss is not None:
        return ss, "v1"
    sys.exit("No SuperSource section found in this profile.")


def learn_op_names(root, fallback_ver):
    """
    Look at macros already on the switcher for SuperSource ops and copy their
    naming. Returns (version, crop_stem, crop_attrs, source) where source says
    whether crop naming was learned or assumed.
    """
    ops = list(root.iter("Op"))
    ids = [op.get("id", "") for op in ops]
    ver = fallback_ver
    if any(i.startswith("SuperSourceV2") for i in ids):
        ver = "v2"
    elif any(re.match(r"SuperSource(Box|Art)", i) for i in ids):
        ver = "v1"

    stem, attrs, source = "Mask", {k: k for k in CROPS + ("enable",)}, "assumed"
    for op in ops:
        m = re.match(r"SuperSource(?:V2)?Box(\w+?)(Enable|Top|Bottom|Left|Right)$", op.get("id", ""))
        if not m or m.group(1) in ("", "X", "Y"):
            continue
        stem, source = m.group(1), "learned from existing macro"
        val_attrs = [a for a in op.attrib if a not in ("id", "superSource", "boxIndex")]
        if val_attrs:
            attrs[m.group(2).lower()] = val_attrs[0]
    return ver, stem, attrs, source


def learn_mp_op(root):
    """Media player 'show still N' op: copy the switcher's own naming from a recorded macro if there is one."""
    for op in root.iter("Op"):
        oid = op.get("id", "")
        if oid.startswith("MediaPlayer") and "Still" in oid:
            attrs = [a for a in op.attrib if a != "id"]
            p = next((a for a in attrs if "player" in a.lower()), "mediaPlayer")
            i = next((a for a in attrs if a != p), "index")
            return (oid, p, i), "learned from existing macro"
    return ("MediaPlayerSourceStillIndex", "mediaPlayer", "index"), "assumed"


def learn_pgm_op(root):
    """Program bus cut op: copy the switcher's own naming from a recorded macro if there is one."""
    for op in root.iter("Op"):
        if op.get("id", "") in ("ProgramInput", "MixEffectBlockProgramInput"):
            attrs = [a for a in op.attrib if a != "id"]
            me = next((a for a in attrs if "mix" in a.lower() or a.lower() == "me"), "mixEffectBlockIndex")
            inp = next((a for a in attrs if a != me), "input")
            return (op.get("id"), me, inp), "learned from existing macro"
    # as ATEM Software Control records it (seen in a real export: ProgramInput mixEffectBlockIndex="2" input="SuperSource")
    return ("ProgramInput", "mixEffectBlockIndex", "input"), "from a recorded macro"


def read_box(ss, idx):
    for b in ss.iter("Box"):
        if int(b.get("index")) == idx:
            cropped = b.get("cropped") == "True"
            box = {"x": float(b.get("xPosition")), "y": float(b.get("yPosition")),
                   "size": float(b.get("size")), "input": b.get("inputSource"),
                   "enabled": b.get("enabled") == "True"}
            for c in CROPS:
                box[c] = float(b.get("crop" + c.capitalize(), 0)) if cropped else 0.0
            return box
    sys.exit(f"Box {idx + 1} not found.")


def apply_overrides(box, pairs):
    alias = {"cropt": "top", "cropb": "bottom", "cropl": "left", "cropr": "right",
             "croptop": "top", "cropbottom": "bottom", "cropleft": "left", "cropright": "right",
             "top": "top", "bottom": "bottom", "left": "left", "right": "right",
             "x": "x", "y": "y", "size": "size", "input": "input"}
    for p in pairs:
        k, _, v = p.partition("=")
        key = alias.get(k.strip().lower())
        if not key:
            sys.exit(f"Unknown --set key '{k}'. Use x, y, size, cropT/B/L/R, input.")
        box[key] = v if key == "input" else float(v)


# ---------------------------------------------------------------- geometry

def pos(p):
    return {k: p[k] for k in KEYS}


def edges(p):
    """Visible rectangle of a (possibly cropped) box: left, right, bottom, top."""
    s = p["size"]
    return (p["x"] + s * (-HALF_W + p["left"]), p["x"] + s * (HALF_W - p["right"]),
            p["y"] + s * (-HALF_H + p["bottom"]), p["y"] + s * (HALF_H - p["top"]))


def border_of(p, b):
    """
    Border plate for picture box p: same centre, slightly bigger, cropped so it
    shows exactly b units on every side of the picture.
    """
    s = p["size"]
    need = max((s * (HALF_W - p["left"]) + b) / HALF_W, (s * (HALF_W - p["right"]) + b) / HALF_W,
               (s * (HALF_H - p["top"]) + b) / HALF_H, (s * (HALF_H - p["bottom"]) + b) / HALF_H)
    S = min(1.0, need)
    q = {"x": p["x"], "y": p["y"], "size": S}
    q["left"] = max(0.0, HALF_W - (s * (HALF_W - p["left"]) + b) / S)
    q["right"] = max(0.0, HALF_W - (s * (HALF_W - p["right"]) + b) / S)
    q["top"] = max(0.0, HALF_H - (s * (HALF_H - p["top"]) + b) / S)
    q["bottom"] = max(0.0, HALF_H - (s * (HALF_H - p["bottom"]) + b) / S)
    return q


def offscreen(p, direction, border):
    """Same size / crop, slid just past the frame edge along one axis."""
    axis, sign = direction
    l, r, b, t = edges(p)
    if axis == "x":
        reach, half = ((r - p["x"]) if sign > 0 else (p["x"] - l)), HALF_W
    else:
        reach, half = ((t - p["y"]) if sign > 0 else (p["y"] - b)), HALF_H
    q = dict(p)
    q[axis] = sign * (half + reach + border + SLIDE_MARGIN)
    return q


def is_full(p):
    return (p["size"] >= 0.999 and abs(p["x"]) < 0.01 and abs(p["y"]) < 0.01
            and all(p[c] < 0.01 for c in CROPS))


def is_offscreen(p):
    l, r, b, t = edges(p)
    return r <= -HALF_W or l >= HALF_W or t <= -HALF_H or b >= HALF_H


def hidden(look, slot):
    """Covered by a full-screen picture on a higher layer, or off-frame."""
    if is_offscreen(look[slot]):
        return True
    return any(s < slot and is_full(p) for s, p in look.items())


def check_layout(home, border):
    notes = []
    items = sorted(home.items())
    for i, (a, pa) in enumerate(items):
        for b, pb in items[i + 1:]:
            la, ra, ba, ta = edges(pa)
            lb, rb, bb, tb = edges(pb)
            gap_x = max(lb - ra, la - rb) - 2 * border
            gap_y = max(bb - ta, ba - tb) - 2 * border
            pair = f"boxes {a + 1} / {b + 1}: " if len(items) > 2 else ""
            if gap_x < 0 and gap_y < 0:
                notes.append(f"{pair}overlap: {-gap_x:.2f} x {-gap_y:.2f} units ({-gap_x * 60:.0f} x {-gap_y * 60:.0f} px @1080), "
                             f"box {min(a, b) + 1} on top{' (borders included)' if border else ''}")
            else:
                notes.append(f"{pair}gap between boxes{' (outside borders)' if border else ''}: "
                             f"{max(gap_x, gap_y):.2f} units ({max(gap_x, gap_y) * 60:.0f} px @1080)")
    for slot, p in home.items():
        l, r, bo, t = edges(p)
        m = min(l + HALF_W, HALF_W - r, bo + HALF_H, HALF_H - t) - border
        if m < 0:
            notes.append(f"WARNING: a box{' border' if border else ''} runs off the frame edge.")
    return notes


# ---------------------------------------------------------------- looks

def build_looks(home, border, exits=None):
    """
    home: {slot: pos} for the two picture boxes (lower slot = higher layer).
    A picture ABOVE the full-screen one is parked off-frame; pictures below it
    stay home (covered).
    """
    slots = sorted(home)
    exits = exits or {}
    park_dir = {s: EXITS[exits[s]] if exits.get(s, "auto") != "auto"
                else ("x", -1 if home[s]["x"] <= 0 else 1) for s in slots}
    park = {}
    for s in slots:
        axis, sign = park_dir[s]
        park[s] = dict(home[s])
        park[s][axis] = sign * (PARK_X if axis == "x" else PARK_Y)
    looks = {"HOME": {s: dict(home[s]) for s in slots}}
    for n, target in enumerate(slots, start=1):
        looks[f"FS{n}"] = {s: dict(FULL) if s == target else dict(park[s] if s < target else home[s])
                           for s in slots}
    return looks, park_dir


# ---------------------------------------------------------------- macro ops

class Ops:
    def __init__(self, cfg):
        self.cfg = cfg
        self.lines = []
        self.last = {}
        self.frames = []            # preview: snapshot of every slot after each sleep
        self.state = {}
        self.arts = []              # preview: which background still is up at each snapshot
        self.art_state = "look"

    def _op(self, name, **attrs):
        prefix = "SuperSourceV2" if self.cfg.ops_version == "v2" else "SuperSource"
        a = {"superSource": str(self.cfg.ss)} if self.cfg.ops_version == "v2" else {}
        a.update(attrs)
        body = " ".join(f'{k}="{html.escape(str(v))}"' for k, v in a.items())
        self.lines.append(f'<Op id="{prefix}{name}" {body}/>')

    def snapshot(self):
        self.frames.append({str(k): dict(v) for k, v in self.state.items()})
        self.arts.append(self.art_state)

    def sleep(self, frames):
        self.lines.append(f'<Op id="MacroSleep" frames="{frames}"/>')
        for _ in range(frames):
            self.snapshot()

    def enable(self, slot):
        self._op("BoxEnable", boxIndex=slot, enable="True")

    def box_input(self, slot, name):
        self._op("BoxInput", boxIndex=slot, input=name)

    def crop_enable(self, slot):
        a = self.cfg.crop_attrs
        self._op(f"Box{self.cfg.crop_stem}Enable", boxIndex=slot, **{a["enable"]: "True"})

    def art(self, option):
        self._op("ArtOption", artOption=option)
        self.cfg_art = option

    def still(self, which):
        """Cut the art's media player to the 'look' still (shadows/frames baked in), the 'clean' one,
        or fade step k ("f0", "f1"... from strong to weak shadow)."""
        if not self.cfg.art_swap:
            return
        op, p_attr, i_attr = self.cfg.mp_op
        if which == "look":
            num = self.cfg.art_swap[0]
        elif which == "clean":
            num = self.cfg.art_swap[1]
        else:
            num = self.cfg.art_fade[int(which[1:])]
        self.lines.append(f'<Op id="{op}" {p_attr}="{self.cfg.art_player}" {i_attr}="{num - 1}"/>')
        self.art_state = which

    def program_cut(self):
        """Program bus of the show's M/E to this SuperSource (a cut)."""
        op, me_attr, in_attr = self.cfg.pgm_op
        self.lines.append(f'<Op id="{op}" {me_attr}="{self.cfg.me - 1}" {in_attr}="{self.cfg.ss_input}"/>')

    def place(self, slot, p, force=False):
        vals = {"x": rnd(p["x"], 2) + 0.0, "y": rnd(p["y"], 2) + 0.0,
                "size": rnd(p["size"], 3) + 0.0}
        for c in CROPS:
            vals[c] = rnd(p[c], 2) + 0.0
        prev = self.last.get(slot, {})
        ch = lambda k: force or vals[k] != prev.get(k)
        if ch("x"):
            self._op("BoxXPosition", boxIndex=slot, xPosition=f'{vals["x"]:g}')
        if ch("y"):
            self._op("BoxYPosition", boxIndex=slot, yPosition=f'{vals["y"]:g}')
        if ch("size"):
            self._op("BoxSize", boxIndex=slot, size=f'{vals["size"]:g}')
        if slot in self.cfg.crop_slots:
            for c in CROPS:
                if ch(c):
                    self._op(f"Box{self.cfg.crop_stem}{c.capitalize()}", boxIndex=slot,
                             **{self.cfg.crop_attrs[c]: f"{vals[c]:g}"})
        self.last[slot] = vals
        self.state[slot] = vals

    def move(self, slot, p, force=False):
        """Picture box plus its border plate."""
        if slot in self.cfg.border_of:
            self.place(self.cfg.border_of[slot], border_of(p, self.cfg.border), force)
        self.place(slot, p, force)


def rnd(v, d):
    """Half-up rounding to d decimals - the same as the builder's Math.round, so the macros, the
    SuperSource section and the app's preview / shadow land on identical switcher steps."""
    k = 10 ** d
    return math.floor(v * k + 0.5 + 1e-9) / k


def lerp(a, b, t):
    return {k: a[k] + (b[k] - a[k]) * t for k in KEYS}


def transition(looks, park_dir, src, dst, cfg, hand_in=False):
    A, B = looks[src], looks[dst]
    ops = Ops(cfg)
    ease = EASES[cfg.ease]

    # Per-picture path: (start, end, snap_after)
    paths = {}
    for s in A:
        start, end, snap = A[s], B[s], None
        if hidden(A, s) and not hidden(B, s):
            # comes into view: jump (unseen) to the off-frame / covered version
            # of its end look, so it slides in or is revealed cleanly (--clear: a box going back to its
            # home spot slides in too; the one going full is still revealed in place as the others leave)
            start = (offscreen(end, park_dir[s], cfg.border)
                     if is_offscreen(A[s]) or (cfg.clear and not is_full(B[s])) else dict(end))
        elif hidden(B, s) and not hidden(A, s):
            if is_offscreen(B[s]):
                # leaving the frame: slide off at its current size, park after
                end, snap = offscreen(A[s], park_dir[s], cfg.border), B[s]
            elif cfg.clear:
                # ends up covered, but --clear: slide out of the way, then snap home unseen
                end, snap = offscreen(A[s], park_dir[s], cfg.border), B[s]
            else:
                # ends up covered: stay put, snap once it's covered
                end, snap = dict(A[s]), B[s]
        elif hidden(A, s) and hidden(B, s):
            start = end = dict(B[s])
        paths[s] = (start, end, snap)

    # Frame 0: explicit start look so the macro is deterministic.
    # Lower layers first, so anything revealed underneath is in place first.
    H = cfg.home
    if cfg.art_mode == "swap" and dst != H:
        ops.art("Background")
    if src != H:
        ops.still("clean")          # a full-screen box covers the background; make sure the clean one is up
    for s in sorted(paths, reverse=True):
        ops.move(s, paths[s][0], force=True)
    ops.snapshot()
    if hand_in:
        # SuperSource now shows the live picture full screen; give the camera box a moment to take the
        # live source (Companion sets it just before running this), then cut program over - nothing changes
        ops.sleep(2)
        ops.program_cut()

    steps = max(1, math.ceil(cfg.frames / cfg.step))
    # The baked shadow sits at the home spots, so it may only show while every picture is within the
    # shadow's reach of its home spot: it steps out as the boxes lift off and only steps back in once
    # they are about to land (one still per frame, finishing after the landing if it has to).
    n = len(cfg.art_fade or [])
    ladder = ["clean"] + [f"f{i}" for i in reversed(range(n))] + ["look"]          # weak to strong
    level = [r / (n + 1) for r in range(n + 2)]
    home = A if src == H else B if dst == H else None
    def allowed(t):
        gap = max(max(abs(a - b) for a, b in zip(edges(lerp(paths[s][0], paths[s][1], t)), edges(home[s])))
                  for s in home if not hidden(home, s)) * PX_PER_UNIT
        return 1.0 if not cfg.shadow_reach else max(0.0, 1 - gap / cfg.shadow_reach)
    rung = len(ladder) - 1 if src == H else 0
    for k in range(1, steps + 1):
        ops.sleep(cfg.step)
        t = ease(min(1.0, k * cfg.step / cfg.frames))
        # the picture that is growing / on top moves last, so its border never lags visibly
        for s in sorted(paths, reverse=True):
            st, en, _ = paths[s]
            ops.move(s, lerp(st, en, t))
        if home is None:
            continue
        a = allowed(t)
        if src == H and rung > 0:
            want = rung - 1
            while want > 0 and (level[want] > a + 1e-9 or k == steps):
                want -= 1                           # past the shadow already: skip the rest of the fade
            rung = want
            ops.still(ladder[rung])
        elif dst == H and rung < len(ladder) - 1 and level[rung + 1] <= a + 1e-9:
            rung += 1
            ops.still(ladder[rung])
    while dst == H and cfg.art_swap and rung < len(ladder) - 1:
        ops.sleep(1)                                # boxes have landed; the shadow settles in under them
        rung += 1
        ops.still(ladder[rung])

    for s in sorted(paths, reverse=True):
        if paths[s][2]:
            ops.move(s, paths[s][2])
    if cfg.art_mode == "swap" and dst == H:
        ops.art("Foreground")
    ops.snapshot()
    return ops


def setup(looks, home_inputs, cfg):
    ops = Ops(cfg)
    H = cfg.home
    used = set(looks[H]) | set(cfg.border_of.values())
    for s in range(4):
        if s not in used:
            ops._op("BoxEnable", boxIndex=s, enable="False")
    for s in sorted(looks[H]):
        ops.enable(s)
        ops.box_input(s, home_inputs[s])
        if s in cfg.border_of:
            ops.enable(cfg.border_of[s])
            ops.box_input(cfg.border_of[s], cfg.border_src)
    for s in sorted(cfg.crop_slots):
        ops.crop_enable(s)
    for s in sorted(looks[H], reverse=True):
        ops.move(s, looks[H][s], force=True)
    ops.art("Background" if cfg.art_mode == "background" else "Foreground")
    ops.still("look")
    ops.snapshot()
    return ops


# ---------------------------------------------------------------- write

def macro_xml(index, name, lines, desc=""):
    out = [f'        <Macro index="{index}" name="{html.escape(name)}" description="{html.escape(desc)}">']
    out += [f"            {l}" for l in lines]
    out.append("        </Macro>")
    return "\n".join(out)


def variant(result, title="", desc=""):
    """Preview data for one build."""
    cfg = result["args"]
    return {"title": title or "Current settings", "desc": desc, "product": result["product"],
            "fps": cfg.fps, "labels": result["labels"],
            "borderSlots": [str(v) for v in cfg.border_of.values()],
            "macros": [{"name": n, "frames": ops.frames, "art": ops.arts} for n, ops, _ in result["macros"]]}


def write_preview(path, variants):
    tpl = (Path(__file__).parent / "preview_template.html").read_text(encoding="utf-8")
    Path(path).write_text(tpl.replace("/*DATA*/null", json.dumps({"variants": variants})), encoding="utf-8")


def make_parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("profile", help="ATEM profile .xml exported from the target switcher")
    ap.add_argument("-o", "--out", help="output .xml (default: '<profile> SS ANIM.xml' next to this script)")
    ap.add_argument("--frames", type=int, default=15, help="transition length in frames (default 15)")
    ap.add_argument("--step", type=int, default=1, help="frames per keyframe; use 2 if a switcher stutters (default 1)")
    ap.add_argument("--ease", choices=EASES, default="cubic")
    ap.add_argument("--ss", type=int, default=0, help="SuperSource index (V2 switchers with more than one)")
    ap.add_argument("--count", type=int, choices=(1, 2, 3, 4), default=2,
                    help="pictures in the home look (default 2). 1-2 can have border plates; 3-4 use every box "
                         "for a picture, so borders go in the art")
    ap.add_argument("--boxes", type=int, nargs="+", default=None, metavar="BOX",
                    help="which boxes in the profile hold the FS1, FS2... pictures (1-4), one per picture. Default "
                         "for 2: 1 3 when the profile already has this tool's layout (box 2 fed from a colour/black), "
                         "else 1 2; otherwise 1..count")
    ap.add_argument("--set", nargs="+", action="append", default=[], metavar=("BOX", "KEY=VAL"),
                    help="override a picture's home look, e.g. --set 2 x=11.42 cropL=3.4 cropR=3.4 "
                         "(BOX is the picture number: 1 = FS1 picture, 2 = FS2 picture...)")
    ap.add_argument("--on-top", type=int, choices=(1, 2, 3, 4), default=1,
                    help="which picture is the top layer (default 1); the rest follow in picture order. A picture "
                         "grows OVER the ones below it; the ones above it move away first")
    ap.add_argument("--exit", choices=["auto"] + list(EXITS), default="auto",
                    help="which way the top picture leaves when the other one goes full screen "
                         "(auto = nearest side edge)")
    ap.add_argument("--fly", default=None, metavar="SPEC",
                    help="rounded + fly-in look: the boxes never move (no move macros, art in Foreground with "
                         "rounded windows); Companion slides full sources in on upstream keys. SPEC lists the keyers, "
                         "e.g. '1:2001:L,2:2002:R' (keyer:input:side) - written into SETUP for the Companion page")
    ap.add_argument("--fly-rate", type=int, default=15, help="fly key rate in frames (default 15)")
    ap.add_argument("--art-mode", choices=["auto", "background", "swap", "foreground"], default="auto",
                    help="background = the art is a full background under the boxes (SuperSource Builder art, always). "
                         "swap = old window-art: Foreground in 2 BOX, Background for full screens. auto = background "
                         "with border plates, swap without (old behaviour)")
    ap.add_argument("--border-px", type=float, default=4,
                    help="border width in pixels at 1920 wide (0 = no borders, use art borders; default 4)")
    ap.add_argument("--border-src", default="Color1",
                    help="border fill: Color1, Color2, or any input id/name (default Color1)")
    ap.add_argument("--shadow-reach", type=float, default=40.0, metavar="PX",
                    help="how far (px at 1080) the baked shadow shows outside a box: during moves the "
                         "shadow only shows while every box is within this of its home spot (0 = off)")
    ap.add_argument("--art-fade", type=int, nargs="*", default=[], metavar="STILL",
                    help="in-between stills (strong to weak shadow) stepped through one per frame between "
                         "--art-swap's LOOK and CLEAN, so the shadow fades instead of cutting")
    ap.add_argument("--art-swap", type=int, nargs=2, metavar=("LOOK_STILL", "CLEAN_STILL"),
                    help="background with shadows/frames baked in (LOOK) and without (CLEAN), as media pool still "
                         "numbers (1-based). Moves cut the art's media player to CLEAN as the boxes start moving "
                         "and back to LOOK as they land in 2 BOX")
    ap.add_argument("--clear", action="store_true",
                    help="boxes that end up covered by the full-screen picture slide out of the way (and back in) "
                         "instead of staying put under it - each by its own side (the top box by --exit)")
    ap.add_argument("--camera", type=int, choices=(0, 1, 2, 3, 4), default=None,
                    help="which picture is the camera box - the one Companion fills with whatever is live "
                         "(1 = FS1...; 0 = none; default 2 for a 2-box look, else none)")
    ap.add_argument("--me", type=int, default=1, help="M/E whose program bus the IN macros cut to SuperSource (default 1)")
    ap.add_argument("--no-hand-in", dest="hand_in", action="store_false",
                    help="leave out the SS IN macros (moves that start from a camera / graphics on program)")
    ap.add_argument("--start-index", type=int, help="first macro slot (default: first free after existing)")
    ap.add_argument("--prefix", default=None, help="macro name prefix (default 'SS ' for 2 pictures, 'SS1 ' / 'SS3 ' / 'SS4 ')")
    return ap


def build(args):
    """Build every macro from a profile. Returns a dict; nothing is written."""
    src_path = Path(args.profile)
    text = src_path.read_text(encoding="utf-8")
    root = ET.fromstring(text)

    ss, ver = find_supersource(root, args.ss)
    args.ops_version, args.crop_stem, args.crop_attrs, crop_source = learn_op_names(root, ver)
    vm = root.find("VideoMode")
    mode = vm.get("videoMode", "") if vm is not None else ""
    m = re.search(r"p(\d+)$|i(\d+)$", mode)
    rate = int(m.group(1) or m.group(2)) if m else 2997
    args.fps = rate / 100 if rate > 100 else rate

    N = args.count
    args.home = f"{N}BOX"
    if args.fly:
        args.art_mode, args.hand_in, args.border_px, args.camera = "foreground", False, 0, 0   # boxes still; borders in the art
    if args.prefix is None:
        args.prefix = "SSF " if args.fly else "SS " if N == 2 else f"SS{N} "
    if args.camera is None:
        args.camera = 2 if N == 2 else 0
    if args.camera > N:
        args.camera = 0
    if args.on_top > N:
        sys.exit(f"--on-top {args.on_top}: there are only {N} pictures.")
    if args.boxes is None:
        if N == 2:
            b2, b3 = read_box(ss, 1), read_box(ss, 2)
            plate = str(b2["input"]) in ("0", "2001", "2002")          # Black / Color1 / Color2
            args.boxes = [1, 3] if plate and b3["enabled"] else [1, 2]
        else:
            args.boxes = list(range(1, N + 1))
    if len(args.boxes) != N:
        sys.exit(f"--boxes needs {N} box numbers, one per picture.")
    pics = [read_box(ss, b - 1) for b in args.boxes]
    for ov in args.set:
        n = int(ov[0])
        if not 1 <= n <= N:
            sys.exit(f"--set BOX must be a picture number 1-{N}.")
        apply_overrides(pics[n - 1], ov[1:])

    # Layers: the --on-top picture is box 1 (top), the rest follow in picture order. With border
    # plates (1-2 pictures) each picture has the box under it for its border: pictures on 1 & 3.
    plates = args.border_px > 0 and N <= 2
    args.border = args.border_px / 60.0 if plates else 0.0
    layers = [args.on_top - 1] + [i for i in range(N) if i != args.on_top - 1]
    slots = [(2 if plates else 1) * layers.index(i) for i in range(N)]       # box index of each picture
    args.border_of = {s: s + 1 for s in slots} if plates else {}
    if args.art_mode == "auto":
        args.art_mode = "background" if plates or N != 2 else "swap"
    args.border_src = input_name(args.border_src)
    args.mp_op, mp_source = learn_mp_op(root)
    args.pgm_op, args.pgm_source = learn_pgm_op(root)
    args.ss_input = input_name(6000 + args.ss)
    art_fill = ss.get("artFillInput", "")
    args.art_player = ((int(art_fill) - 3000) // 10 - 1) if art_fill.isdigit() and 3000 < int(art_fill) < 4000 else None
    if args.art_swap and args.art_player is None:
        sys.exit("--art-swap needs the SuperSource art fed from a media player (it is fed from input "
                 f"{art_fill or '?'} on this switcher).")

    home = {slots[i]: pos(pics[i]) for i in range(N)}
    home_inputs = {slots[i]: input_name(pics[i]["input"]) for i in range(N)}
    uses_crop = {s for s in slots if any(home[s][c] for c in CROPS)}
    args.crop_slots = uses_crop | set(args.border_of.values())

    looks, park_dir = build_looks(home, args.border, {min(slots): args.exit})
    # FS1, FS2... follow the picture order the user gave, not the layer order
    order = sorted(slots)
    names = {"HOME": args.home, **{f"FS{order.index(slots[i]) + 1}": f"FS{i + 1}" for i in range(N)}}
    looks = {names[k]: v for k, v in looks.items()}

    H, FS = args.home, [f"FS{i + 1}" for i in range(N)]
    plan = [p for f in FS for p in ((H, f), (f, H))] + [(a, b) for a in FS for b in FS if a != b]

    short = {i.get("id"): i.get("shortName") for i in root.iter("Input") if i.get("shortName")}
    # Macros already named like ours (an earlier run restored onto this switcher) are
    # replaced in their own slots; new ones go after the last used slot.
    ours = {mc.get("name"): int(mc.get("index")) for mc in root.iter("Macro")
            if mc.get("name", "").startswith(args.prefix)}
    existing = [int(mc.get("index")) for mc in root.iter("Macro")]
    taken = set(existing) - set(ours.values())
    free = args.start_index if args.start_index is not None else (max(taken) + 1 if taken else 0)

    ids = [input_id(home_inputs[slots[i]]) for i in range(N)]
    if args.camera and ids[args.camera - 1] >= 10000:
        # the camera box is fed by an M/E (a camera-cut M/E): it already follows what's live there, and a key
        # must never put another source in it - so it's a fixed box: M/E program live -> hand in through it
        args.camera = 0
    desc = (f"sources, borders, art, home look · pictures {','.join(str(s + 1) for s in slots)} · "
            f"camera {'FS%d' % args.camera if args.camera else 'none'} · inputs {','.join(map(str, ids))}")
    if N == 2 and args.camera:                                  # older Companion pages read the graphics input here
        desc += f" · gfx {ids[2 - args.camera]}"
    if args.fly:
        desc += f" · fly {args.fly} · rate {args.fly_rate} · fps {args.fps:g} · ease {args.ease}"
    macros = [(f"{args.prefix}{H} SETUP", setup(looks, home_inputs, args), desc + f" · me {args.me}")]
    for src, dst in ([] if args.fly else plan):
        macros.append((f"{args.prefix}{src}>{dst}", transition(looks, park_dir, src, dst, args),
                       f"{args.frames}f {args.ease} ease"))
    if args.hand_in:
        for src, dst in [p for a in FS for p in [(a, H)] + [(a, b) for b in FS if b != a]]:
            macros.append((f"{args.prefix}IN {src}>{dst}", transition(looks, park_dir, src, dst, args, hand_in=True),
                           f"from {src} live on M/E {args.me}: cut to SuperSource, then {args.frames}f {args.ease}"))

    blocks, slots_used = [], []
    for name, ops, desc in macros:
        if name in ours and args.start_index is None:
            idx = ours[name]
        else:
            while free in taken:
                free += 1
            idx, free = free, free + 1
            if idx in taken:
                sys.exit(f"Macro slot {idx + 1} is already used. Pick another --start-index.")
        taken.add(idx)
        slots_used.append(idx)
        blocks.append(macro_xml(idx, name, ops.lines, desc))
    new = "\n".join(blocks)
    for name in ours:                              # drop the old copies before inserting
        text = re.sub(r'\n\s*<Macro index="\d+" name="' + re.escape(html.escape(name)) + r'"[^>]*>.*?</Macro>',
                      "", text, flags=re.S)

    if "</MacroPool>" in text:
        text = text.replace("    </MacroPool>", new + "\n    </MacroPool>", 1)
    elif re.search(r"<MacroPool\s*/>", text):
        text = re.sub(r"<MacroPool\s*/>", "<MacroPool>\n" + new + "\n    </MacroPool>", text, count=1)
    else:
        text = text.replace("</Profile>", "    <MacroPool>\n" + new + "\n    </MacroPool>\n</Profile>", 1)
    text = write_layout(text, args, looks[H], home_inputs)
    ET.fromstring(text)  # sanity: output still parses

    return {"args": args, "text": text, "src_path": src_path, "product": root.get("product", "?"),
            "mode": mode, "crop_source": crop_source, "home": home,
            "home_inputs": home_inputs, "macros": macros, "slots": slots_used, "pic_slots": slots,
            "replaced": sorted(ours),
            "labels": {str(slots[i]): {"name": short.get(str(pics[i]["input"]), home_inputs[slots[i]]), "fs": i + 1}
                       for i in range(N)}}


def main():
    args = make_parser().parse_args()
    r = build(args)

    out = Path(args.out) if args.out else Path(__file__).parent / f"{r['src_path'].stem} SS ANIM.xml"
    out.write_text(r["text"], encoding="utf-8")
    preview = out.with_suffix(".preview.html")
    write_preview(preview, [variant(r)])

    print(f"{r['product']} | {r['mode']} | SuperSource {args.ss} | ops {args.ops_version.upper()} | "
          f"crop ops '{args.crop_stem}' ({r['crop_source']})")
    home, home_inputs = r["home"], r["home_inputs"]
    for i, s in enumerate(r["pic_slots"]):
        h = home[s]
        crop = " ".join(f"{c[0].upper()}{h[c]:g}" for c in CROPS if h[c])
        print(f"  FS{i + 1} picture -> box {s + 1}: {home_inputs[s]:12} x {h['x']:g}  y {h['y']:g}  "
              f"size {h['size']:g}{'  crop ' + crop if crop else ''}"
              + (f"   border -> box {args.border_of[s] + 1} ({args.border_src}, {args.border_px:g}px)"
                 if s in args.border_of else ""))
    for n in check_layout(home, args.border):
        print("  " + n)
    for idx, (name, ops, _) in zip(r["slots"], r["macros"]):
        print(f"  macro {idx + 1:>3}: {name:18} {len(ops.lines):4} ops{'  (replaced)' if name in r['replaced'] else ''}")
    print(f"wrote {out}\nwrote {preview}")


if __name__ == "__main__":
    main()
